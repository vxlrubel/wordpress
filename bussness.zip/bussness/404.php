<?php get_header(); ?>
	<section class="clearfix">
		<div class="container-fluid">
			<div class="row">
				<div class="col-12">
					<h2 class="not-found-page py-3">
						<span>4</span>
						<span class="far fa-frown-open"></span>
						<span>4</span>
					</h2>
					<h3 class="text-center display-5 py-3">
						Sorry! The Page Not Found
					</h3>
					<p class="text-center py-3">
						The page you were looking for could not be found.
					</p>
					<p class="text-center mb-5">
						<a class="back-to-home" href="<?php echo esc_url(home_url('/')); ?>">Back To Home</a>
					</p>
				</div>
			</div>
		</div>
	</section>

<?php get_footer(); ?>