<?php global $bussness; ?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<?php wp_head(); ?>
</head>
<body <?php body_class( 'bss-home' ); ?> >
<?php wp_body_open(); ?>
	<header class="clearfix header" id="smooth0nl">
		<!-- header top -->
		<div class="container-fluid bg-dark py-2 py-md-0 header-top">
			<div class="row">
				<div class="col-12">
					<div class="row">
						<div class="col-md-4 col-sm-6 text-white d-none d-md-block">
							<div class="follow d-flex h-100">
								<p class="small h-100 d-flex align-items-center">
									<span>Phone Number : <?php echo $bussness['cds_phone']; ?> </span>
									<span>_| Email : <?php echo $bussness['cds_email']; ?></span>
								</p>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 d-none d-md-block">
							<?php BSS()->layout->social_icon(); ?>
						</div>
						<div class="col-md-2 col-sm-6">
							<div class="date text-white d-flex h-100 justify-content-end">
								<p class="d-flex align-items-center h-100 date-visiblity"><?php the_time('__F d, Y'); ?></p>
							</div>
						</div>
						<!-- search area -->
						<div class="col-md-3 col-sm-6">
								<form action="<?php echo esc_url(home_url('/')); ?>" class="form d-flex h-100" method="GET">
									<input type="text" class="search-key" name="s" value="<?php echo get_search_query(); ?>" required>
									<button type="submit" class="search-btn"><span class="search-icon fas fa-search"></span></button>
								</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- header end -->
		<div class="container-fluid bg-light header-end" style="background-image: url(<?php header_image(); ?>); display: <?php echo $bussness['hm_menu'] > 0 ? 'block' : 'none'; ?>;">
			<div class="row">

				<?php if ($bussness['hm_position'] == 1): ?>

				<div class="col-md-3 text-center text-md-left">
					<?php BSS()->theme->logo(); ?>
				</div>
				<div class="col-md-7">
					<button  type="button" class="menu-toggle d-block d-md-none w-100 p-2 d-flex justify-content-between align-items-center">
						<span>Menu</span>
						<span class="fas fa-bars"></span>
					</button>

					<nav class="nav">
						<?php BSS()->theme->primary_menu();?>
					</nav>
				</div>

				<!-- user profile -->
				<div class="col-md-2 d-none d-md-block">
					<div class="user-profile">
						<ul class="list-unstyled d-flex align-items-center">
							<?php 
								if ( is_user_logged_in() ) {
									do_action( 'bussness_user_login' );
								}else {
									do_action( 'bussness_user_logout' );
								}
							 ?>
						</ul>
					</div>
				</div>

				<?php elseif ($bussness['hm_position'] == 2) : ?>

				<div class="col-md-9">
					<button  type="button" class="menu-toggle d-block d-md-none w-100 p-2 d-flex justify-content-between align-items-center">
						<span>Menu</span>
						<span class="fas fa-bars"></span>
					</button>

					<nav class="nav">
						<?php BSS()->theme->primary_menu();?>
					</nav>
				</div>
				<div class="col-md-3 col-sm-6">
					<?php BSS()->theme->logo(); ?>
				</div>

				<?php endif; ?>
			</div>
		</div>

		<?php if ( is_single() || is_page() || is_archive() || is_singular() ): ?>
		<div class="container-fluid d-none d-md-block breadcrumb-visibility">
			<div class="row">
				<div class="col-12">
					<?php BSS()->theme->breadcrumb(); ?>
				</div>
			</div>
		</div>
		<?php endif; ?>

		<div class="container-fluid ticker-visibility">
			<div class="row">
				<?php BSS()->theme->ticker(); ?>
			</div>
		</div>
	</header>

	<section class="clearfix d-none">
		<div class="container-fluid">
			<div class="row">
				<div class="owl-carousel opt-slides" >
					<?php 
						$terms = $bussness['opt-slides'];
						foreach ($terms as $term) {
							$image = $term['image'];
							$name = $term['title'];
							$description = $term['description'];
							$url = $term['url'];
							$content = "<div class=\"opt-slides-items\"> \n";
							$content .= "<img src=\"$image\" alt=\"$name\"> \n";
							$content .= "<div> \n";
							$content .= "<h3>$name</h3> \n";
							$content .= "<span>$description</span> \n";
							$content .= "</div> \n";
							$content .= "</div> \n";
							echo $content;
						}
					 ?>
				 </div>
			</div>
		</div>
	</section>
	<section class="preloader-area">
		<?php 
		 $effect = $bussness['preloader_change_effect'];
		 $effect == 1 ? BSS()->preloader->wave() : '';
		 $effect == 2 ? BSS()->preloader->ajax_loader() : '';
		 $effect == 3 ? BSS()->preloader->ajax_door() : '';
		 $effect == 4 ? BSS()->preloader->ajax_grow() : '';
		 $effect == 5 ? BSS()->preloader->ajax_loading() : '';
		 $effect == 6 ? BSS()->preloader->ajax_load() : '';
		 $effect == 7 ? BSS()->preloader->ajax_hack() : '';

		 ?>
		 
	</section>


	<?php 

	BSS()->theme->float_menu();
	$layout = $bussness['tl_layout'];
	echo '<input class="theme-layout" type="hidden" value="'.$layout.'">';

	// get author name
	$get_author = new WP_Query([
		'post_type' => 'post',
		"posts_per_page"=> 1
	]);
	while ( $get_author-> have_posts()) {
		$get_author-> the_post();
		$author_post_link = esc_url(get_author_posts_url( get_the_author_meta('ID'), get_the_author_meta('user_nicename') ));
		printf('<input class="get_author" type="hidden" value="'.esc_attr(get_the_author()).'">');
		printf('<input class="get_author_link" type="hidden" value="'.$author_post_link.'">');
		$avatar= get_avatar( get_the_author_meta( 'ID') , 40 );
		printf('<p class="get_avatar" hidden>'.$avatar.'</p>');

	}
