<?php 
	if ( post_password_required() ) {
		return;
	}
 ?>
<?php if ( $comments ): ?>
<div class="col-12 mb-3">
	<h2 class="comment-title">
		<?php
			$comments_number = absint( get_comments_number() );
			if ( ! have_comments() ) {
				_e( 'Post a comment', 'bussness' );
			}
			elseif ( '1' === $comments_number ) {
				/* translators: %s: post title */
				printf( _x( 'One reply on &ldquo;%s.&rdquo;', 'comments title', 'bussness' ), esc_html( get_the_title() ) );
				}
			else {
				echo sprintf(
				/* translators: 1: number of comments, 2: post title */
				_nx(
				'%1$s reply on &ldquo;%2$s&rdquo;',
				'%1$s replies on &ldquo;%2$s.&rdquo;',
				$comments_number,
				'comments title',
				'bussness'
				),
				number_format_i18n( $comments_number ),
				esc_html( get_the_title() )
				);
			}
			?>
	</h2>
	<ul class="comment-list p-0 py-3">
		<?php 
		 wp_list_comments([
			'style'             => 'div',
			'callback'          => 'bss_callback_comments_list',
			'avatar_size'       => 64,
		 ]);
		 ?>
	</ul>
</div>
<?php endif; ?>

<div class="col-12 mb-3">
	<?php if ( comments_open() || pings_open() ) : ?>
		<?php 
			if ( $comments ) {
				echo '<hr class="styled-separator is-style-wide" aria-hidden="true" />';
			}
			$custom_comment_fields = '<p class="custom-text-comment">';
			$custom_comment_fields .= '<label for="comment">Comment</label>';
			$custom_comment_fields .= '<textarea class="pt-2" id="comment" name="comment" maxlength="65525" required="required"></textarea></p>';
			comment_form( [
				'cancel_reply_link'    => __( 'Cancel', 'bussness' ),
				'label_submit'         => __( 'Post Comment', 'bussness' ),
				'class_form'           => 'comments-box',
				'id_submit'            => 'cs_form_submit',
				'logged_in_as'         => '',
				'title_reply_before'   => '<h4 class="mb-3 post-comment">',
				'title_reply_after'    => '</h4>',
				'title_reply'          => __( 'Post A Comment', 'bussness' ),
				'title_reply_to'          => __( 'Post A Comment To %s', 'bussness' ),
				'comment_field'        => $custom_comment_fields
			] );
		 ?>
	<?php elseif ( is_single() ) : ?>
		<?php 
			if ( $comments ) {
				echo '<hr class="styled-separator is-style-wide" aria-hidden="true" />';
			}
			echo '<div class="comment-respond" id="respond">';
			printf( '<p class="comments-closed">'.esc_html__( 'Comments are closed.', 'bussness' ).'</p>');
			echo '</div>';
		 ?>
	<?php endif; ?>
</div>

<div class="col-12 mb-3">
	<?php 
	 $comment_pagination = paginate_comments_links( [
		'echo'      => false,
		'end_size'  => 0,
		'mid_size'  => 0,
		'next_text' => ' <span aria-hidden="true">&raquo;</span>',
		'prev_text' => '<span aria-hidden="true">&laquo;</span> ',
	 ] );
	 if ( $comment_pagination ){
	 	$pagination_classes = '';
		if ( false === strpos( $comment_pagination, 'prev page-numbers' ) ) {
			$pagination_classes = ' only-next';
		}
		echo '<div class="comments-napigation">';
		echo wp_kses_post( $comment_pagination );
		echo '</div>';
	 }
	 ?>
</div>