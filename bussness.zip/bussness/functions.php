<?php 

if(! function_exists('bussness_setup_theme')) : 
	function bussness_setup_theme(){
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		load_theme_textdomain( 'bussness', get_template_directory() . '/languages' );
		add_theme_support( 'custom-header', array(
			'default-image' => get_template_directory_uri().'/lib/img/header-image.jpg'
		));
		add_theme_support( 'custom-background' );

		add_image_size( 'slider-thumb', 254, 174, true );
		add_image_size( 'latest-post-thumb', 650, 300, true );
		add_image_size( 'post-t-cm', 420, 270, true );
		add_image_size( 'search-thumb', 90, 60, true );
		add_image_size( 'service', 311, 208, true );
		add_image_size( 'slick', 600, 400, true );
		add_image_size( 'slick-thumb', 100, 90, true );
		add_image_size( 'squire', 50, 50, true );
		add_image_size( 'archive', 64, 64, true );
		add_image_size( 'author', 100, 100, true );
		add_image_size( 'flip-slide', 400, 400, true );
		add_image_size( 'unic-width', 1000, 600, true );
		add_image_size( 'swipe', 500, 200, true );

	}
endif;
add_action('after_setup_theme', 'bussness_setup_theme');

if(! function_exists('bussness_menus')) :
/**
  *
  * @see bussness menu register.
  *
  */
	function bussness_menus(){
		$location = array(
			'primary-menu' => __('Main Menu', 'bussness'),
			'float-menu' => __('Floating Menu', 'bussness')
		);
		register_nav_menus( $location );
	}
endif;

add_action( 'init', 'bussness_menus' );

// admin panel custom script
add_action('admin_enqueue_scripts', 'bussness_admin_panel_scripts');

if(! function_exists('bussness_admin_panel_scripts')) :
	function bussness_admin_panel_scripts(){
		wp_enqueue_style( 'bussness-admin-panel-style', get_theme_file_uri( 'lib/custom/admin-panel/css/admin-panel-custom-style.css' ), array( 'imgareaselect' ), true, 'all');
		wp_enqueue_media();
		wp_enqueue_script( 'bussness-admin-panel-script', get_theme_file_uri( 'lib/custom/admin-panel/js/admin-panel-custom-script.js' ), array( 'jquery' ), false, false );
	}
endif;


// register sidebar and widget
add_action('widgets_init', 'bussness_widget');

if(! function_exists('bussness_widget')) :
	function bussness_widget(){
		
		BSS()->sidebars->left();

		BSS()->sidebars->right();

		BSS()->sidebars->footer1();

		BSS()->sidebars->footer2();

		BSS()->sidebars->footer3();

		BSS()->sidebars->footer4();

		// register widget
		register_widget( 'Author_Information' );

		register_widget( 'Author_Info_Categories' );

		register_widget( 'Author_Info_Iags' );

		register_widget( 'Author_Info_Gallery' );

		register_widget( 'Author_Flip_Slide' );

		register_widget( 'Author_Swipe_Up' );
	}
endif;

/**
 * @see ALL REQUIRED FILE
 */
if( file_exists( get_template_directory(). '/inc/init.php' ) ) {
	require_once get_template_directory(). '/inc/init.php';
}

if ( !function_exists( 'BSS' ) ) {
	function BSS() {
		return new Bussness_Setup_Theme();
	}
}
