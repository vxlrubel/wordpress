<?php get_header(); ?>

	<section class="clearfix">
		<div class="container-fluid">
			<div class="row">
				<?php get_sidebar(); ?>
				<div class="col-md-6 col-sm-12">
				<?php do_action( 'bussness_search_query_result' ); ?>
				</div>

				<?php 
					get_template_part( 'template-part/content', 'right-sidebar' );
				 ?>
			</div>
		</div>
	</section>

<?php get_footer(); ?>