<?php
/**
 * Template Name: frontpage
 */
get_header();
	do_action( 'section_before' ); ?>
		<div class="col-md-12" id="smooth1st">
			<div class="owl-carousel carousel-slider">
				<?php get_template_part( 'template-part/content', 'slider' ); ?>
			</div>
		</div>
	<?php do_action( 'section_after' ); ?>



	<!-- feature post -->
	<section class="clearfix mb-3 feature-visibility" id="smooth2nd">
		<div class="container-fluid">
			<?php BSS()->frontpage->feature_post(); ?>
		</div>
	</section>

	<section class="clearfix" id="smooth3rd">
		<div class="container-fluid">
			<?php BSS()->frontpage->carousel_unic(); ?>
		</div>
	</section>

	<section class="clearfix static-visibility" id="smooth4th">
		<div class="container-fluid my-4">
			<div class="row">
				<div class="col-md-6 col-sm-12">
					<img src="<?php echo $bussness['st_thumb']['url']; ?>">
				</div>
				<div class="col-md-6 col-sm-12">
					<h4><?php echo $bussness['st_title']; ?></h4>
					<p class="text-justify">
						<?php echo $bussness['st_description']; ?>
					</p>
				</div>
			</div>
		</div>
	</section>

	<section class="clearfix atb_srv_section_visibility" id="smooth5th">
		<div class="container-fluid">
			<?php BSS()->frontpage->services(); ?>
		</div>
	</section>

	<section class="clearfix atb_abt_section_visibility" id="smooth6th">
		<div class="container-fluid">
			<?php BSS()->frontpage->about(); ?>
		</div>
	</section>

	<section class="clearfix missed-post" id="smooth7th">
		<div class="container-fluid">
			<div class="row">
				<?php 
					get_template_part( 'template-part/content', 'missed-post' );
				 ?>
			</div>
		</div>
	</section>

	<section class="clearfix portfolio">
		<div class="container-fluid">
			<?php BSS()->frontpage->isotop(); ?>
		</div>
	</section>

	<div class="sticky-menu">
		<a href="#smooth0nl" class="smooth-scroll-link"></a>
		<a href="#smooth1st" class="smooth-scroll-link"></a>
		<a href="#smooth2nd" class="smooth-scroll-link"></a>
		<a href="#smooth3rd" class="smooth-scroll-link"></a>
		<a href="#smooth4th" class="smooth-scroll-link"></a>
		<a href="#smooth5th" class="smooth-scroll-link"></a>
		<a href="#smooth6th" class="smooth-scroll-link"></a>
		<a href="#smooth7th" class="smooth-scroll-link"></a>
		<a href="#smoothlst" class="smooth-scroll-link"></a>
	</div>


<?php get_footer(); ?>