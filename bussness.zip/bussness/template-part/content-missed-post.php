<?php global $bussness; ?>
<div class="col-md-12 col-sm-12" >
	<div class="row">
		<div class="col-12">
			<h2 class="capitalize" style="display: <?php echo $bussness['mp_check']; ?>"><?php echo $bussness['mp_post']; ?></h2>
		</div>
		<!-- single missed post -->
		<?php 
			$lposts = new WP_Query(array(
				'post_type' => 'post',
				'posts_per_page' => 4,
				'order' => 'DSC'
			));
			if ($lposts -> have_posts()): 
			while($lposts -> have_posts()) : $lposts -> the_post();
		?>

			<div class="col-md-3 col-sm-6 widget mb-2">
				<h3 class="capitalize"><a class="text-info text-decoration-none" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<div>
					<?php the_post_thumbnail( 'service', array('class' => 'mb-2') ); ?>
				</div>
				<p class="text-justify">
					<?php wp_trim(25); ?>
				</p>
				<p class="small missed-category">
					<span class="fab fa-facebook-messenger"></span>
					<span><?php comments_number(); ?></span>
					<span><?php the_category(', '); ?></span>
					<span><?php the_time('_F d, Y | g:i:s A'); ?></span>
				</p>
			</div>

		<?php 
			endwhile;
			endif; 
		?>
	</div>
</div>