
<!-- navigation -->

<?php 
$prev_post = get_previous_post();
$prev_thumb = esc_url( get_the_post_thumbnail_url( $prev_post->ID ) );
$next_post = get_next_post();
$next_thumb = esc_url( get_the_post_thumbnail_url( $next_post->ID ) );
if( is_single()):
	if ( $prev_post || $next_post ):
	 ?>
	<div class="col-12">
		<div class="row">
			<!-- prev post link -->
			<div class="col-sm-6 next-previous-post">
				<?php if ( $prev_post ): ?>
					
				<a href="<?php echo esc_url( get_permalink( $prev_post->ID ) ); ?>" style="background: url(<?php echo $prev_thumb; ?>);">
					<span>
						<?php 
						printf(__('Prev : '). wp_kses_post( get_the_title( $prev_post->ID ) ) );
						 ?>
					</span>
				</a>
				<?php endif; ?>
			</div>

			<!-- next post link -->
			<div class="col-sm-6 next-previous-post">
				<?php if ( $next_post ): ?>
				<a href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>" style="background: url(<?php echo $next_thumb; ?>);" >
					<span>
						<?php 
						printf(__('Next : '). wp_kses_post( get_the_title( $next_post->ID ) ) );
						 ?>
					</span>
				</a>
				<?php endif; ?>
				
			</div>
		</div>
	</div>

	<?php 
	endif;
endif;