<div>
	<h3>
		<?php 
			printf( __( 'No Post Available.', 'bussness' ) );
		 ?>
	</h3>
	<p>
		<a href="<?php echo esc_url( home_url( '/wp-admin/post-new.php' ) ); ?>" class="create-post">
			<?php 
				printf( __( 'Create Post', 'bussness' ) );
			 ?>
		</a>
	</p>
</div>