	<div class="row">
		<div class="col-12 text-center">
			<?php 
				the_title( '<h2 class="text-uppercase">', '</h2>' );

				edit_post_link( 'Edit Page Content', '<span class="far fa-edit edit-page-link"></span>', '', get_the_ID(), 'edit-page-link' );
			 ?>
		</div>
		<div class="col-12">
		<?php 
			the_content();

			wp_link_pages(
				array(
					'before' => '<div class="page-links">' . __( 'Pages:', 'bussness' ),
					'after'  => '</div>',
				)
			);

		 ?>
	</div>
