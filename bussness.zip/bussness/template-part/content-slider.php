<?php global $bussness; 
		$slider = new WP_Query(array(
			'post_type' => 'post',
			'posts_per_page' => $bussness['so_slider']
		));
		 if ($slider -> have_posts()): 
			while($slider -> have_posts()) : $slider -> the_post(); ?>
	  	<div class="slider position-relative">
		   <?php the_post_thumbnail( 'slider-thumb' ); ?>
		   <div class="position-absolute p-2">
		  		<a href="<?php the_permalink(); ?>" class="h5 text-decoration-none text-light m-0 p-0"><?php the_title(); ?></a>
		  		<p class="small m-0 text-light"><?php wp_trim(3); ?></p>
		   </div>
	 	</div>
	 	<?php
			endwhile;
		 endif;