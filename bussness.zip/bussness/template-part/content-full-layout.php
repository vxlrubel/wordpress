

<?php if ( have_posts() ): ?>
<?php while( have_posts() ) : the_post(); ?>
<div class="col-12">
	<div class="full-layout-thumb mb-3">
		<?php the_post_thumbnail( 'post-thumbnail', ['class' => 'w-100'] ); ?>
		<div class="full-layout-thumb-content">
			<div>
				<a href="<?php the_post_thumbnail_url(); ?>" class="layout-preview-link" data-fancybox="post"><span class="fas fa-thumbtack"></span></a>
				<a href="<?php the_permalink(); ?>" class="layout-preview-link"><span class="fas fa-link"></span></a>
				<?php the_title( '<h2>', '</h2>' ); ?>
				<p>
					<?php wp_trim( 10 ); ?>

				</p>
			</div>
		</div>
	</div>
	
	<?php the_title( '<h2 class="full-layout-title">', '</h2>' ); ?>
	<div class="full-layout-content">
		<?php wp_trim( 10 ); ?>
	</div>
	<div class="full-layout-details">
		<span><?php the_time( 'F d, Y | g:i:s A |' ); ?></span>
		<?php BSS()->post-> comments_popup_link(); ?>
		<a href="<?php the_permalink(); ?>" class="read-more">Read More</a>

	</div>
</div>
<?php endwhile; ?>
<div class="col-12 mt-3">
	<?php 
	the_posts_pagination(array(
		'screen_reader_text' => ' ',
		'prev_text' => '&laquo;',
		'next_text' => '&raquo;'
	));
	 ?>
</div>
<?php else: ?>
	<?php 
	 echo "<div class=\"col-12 mt-3\"> \n";
	 get_template_part( 'template-part/content', 'none' );
	 echo "</div>";
	 ?>
<?php endif; ?>
<?php wp_reset_postdata(); ?>