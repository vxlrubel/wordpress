<?php global $bussness; ?>
<aside class="col-md-3 col-sm-12">
	<div class="row" style="display: <?php echo $bussness['sidebars_all'] > 0 ? 'block' : 'none'; ?>; display: <?php echo $bussness['sa_right_sidebar']; ?>">
		
		<?php dynamic_sidebar('bussness-sidebar-second'); ?>
	</div>
</aside>