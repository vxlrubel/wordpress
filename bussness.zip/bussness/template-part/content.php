<div class="col-12 mb-2">
	<div class="row">
		<div class="col-12 position-relative">
			<?php the_post_thumbnail('latest-post-thumb'); ?>
			<p class="content-cat text-center">
				<a class="text-decoration-none text-dark h5 text-capitalize" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</p>
		</div>
		<div class="col-12">
			<p class="small mt-2 latest-post-category mb-0">
				<span class="fab fa-facebook-messenger"></span>
				<span><?php comments_number(); ?></span>
				<span><?php the_time( '_F d, Y' ); ?></span>
				<span>| <?php the_category(', '); ?></span>
			</p>
			<p class="text-justify mb-1 py-3">
				<?php wp_trim(35); ?>
			</p>
		</div>
	</div>
</div>