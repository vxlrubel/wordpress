<?php $prefix = '_bussness_'; ?>

<div class="col-md-3 col-sm-6">
	<div>
		<?php if (get_post_meta( get_the_ID(), $prefix.'image', true )): ?>
		<img class="about-image" src="<?php wp_option($prefix.'image'); ?>" alt="<?php wp_option($prefix.'name'); ?> <?php wp_option($prefix.'designation'); ?>">
		<?php endif ?>
	</div>

	<div class="mb-3">
		<span class="d-block small">Name : <?php wp_option($prefix.'name'); ?></span>
		<span class="d-block small">Designation : <?php wp_option($prefix.'designation'); ?></span>
		<button class="btn-sm bg-secondary text-white" type="button" data-toggle="collapse" data-target="#<?php wp_option($prefix.'info_connector'); ?>">
		    <?php wp_option($prefix.'info_button_label'); ?>
		</button>
		<button type="button" class="btn-sm"  data-toggle="modal" data-target="#<?php wp_option($prefix.'info_form'); ?>"><?php wp_option($prefix.'info_button'); ?></button>

	   <div class="bg-secondary text-white collapse px-2" id="<?php wp_option($prefix.'info_connector'); ?>">
			<?php wp_option($prefix.'info'); ?>
	   </div>

		<div class="modal fade" id="<?php wp_option($prefix.'info_form'); ?>" tabindex="-1" role="dialog" aria-labelledby="contact-box" aria-hidden="true">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="contact-box">Hi I'm <?php wp_option($prefix.'name'); ?>, <span class="small text-info"> If you contact me than fill up the form.</span></h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <div class="modal-body">
		        <form>
		          <div class="form-group m-0">
		            <label for="name" class="col-form-label">Name:</label>
		            <input type="text" class="form-control" id="name">
		          </div>
		          <div class="form-group m-0">
		            <label for="email" class="col-form-label">Email Address:</label>
		            <input type="text" class="form-control" id="email">
		          </div>
		          <div class="form-group m-0">
		            <label for="message-text" class="col-form-label">Message:</label>
		            <textarea class="form-control" id="message-text"></textarea>
		          </div>
		        </form>
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" class="btn btn-sm btn-primary">Send message</button>
		      </div>
		    </div>
		  </div>
		</div>

	</div>
</div>