<?php global $bussness; ?>
<div class="col-md-6 col-sm-12" style="display: <?php echo $bussness['lp_post'][0] > 0 ? 'block' : 'none';  ?>;">
	<div class="row">

		
		<!-- single post -->

	<?php 
	if (have_posts()) {
		while (have_posts()) : the_post();
			get_template_part( 'template-part/content', get_post_type() );
		endwhile;
	} else {
		echo "<div class=\"col-12 mt-3\"> \n";
		get_template_part( 'template-part/content', 'none' );
		echo "</div>";
	}
	 ?>

		<!-- pagination -->
		<div class="col-12 mt-3">
			<?php 
			the_posts_pagination(array(
				'screen_reader_text' => ' ',
				'prev_text' => '&laquo;',
				'next_text' => '&raquo;'
			));
			 ?>
		</div>
	</div>
</div>