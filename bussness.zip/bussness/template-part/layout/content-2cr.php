<?php 
 get_template_part( 'template-part/layout/2cl/content', get_post_type() );
 get_template_part( 'template-part/layout/2cl/content', 'sidebar' );
