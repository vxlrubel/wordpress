<?php global $bussness; ?>
<div class="col-md-8 col-sm-12" style="display: <?php echo $bussness['lp_post'][0] > 0 ? 'block' : 'none';  ?>">
	<div class="row">
		<!-- single post -->

	<?php 
	if (have_posts()) {
		while (have_posts()) : the_post();
		?>
		<div class="col-12 mb-4">
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<?php the_post_thumbnail( 'post-t-cm' ); ?>
				</div>
				<div class="col-md-6 col-sm-6">
					<p class="m-0 mt-5 cm-category">
						<?php the_category(', '); ?>
					</p>
					<?php bss_link( get_permalink(), get_the_title(), 'text-decoration-none text-dark h4 text-capitalize' ); ?>
					<p class="m-0 small">
						<span><?php the_time('_F d, Y'); ?> |</span>
						<span>| <?php the_author(); ?></span>
					</p>
					<p class="text-justify mb-1">

						<?php wp_trim(15); ?>
					</p>
					<p class="small mt-1 latest-post-category">
						<span class="fab fa-facebook-messenger"></span>
						<span><?php comments_number(); ?></span>
						<span><?php the_time( '_F d, Y' ); ?></span>
						<span>| <?php the_category(', '); ?></span>
					</p>
				</div>
			</div>
		</div>
	<?php 
		endwhile;
	} else { ?>

		<div class="col-12 mb-4">
			<?php get_template_part( 'template-part/content', 'none' ); ?>
		</div>
<?php 
	}
	 ?>

		<!-- pagination -->
		<div class="col-12 mt-3">
			<?php 
			the_posts_pagination(array(
				'screen_reader_text' => ' ',
				'prev_text' => '&laquo;',
				'next_text' => '&raquo;'
			));
			 ?>
		</div>
	</div>
</div>