<div class="col-md-8 col-sm-12">
	<div class="row">
		<!-- single post -->
		<div class="col-12 mb-2">
			<div class="row">
				<div class="col-12 text-center">
					<h2 class="text-uppercase bg-info mb-0 pt-3 text-white"><?php the_title(); ?></h2>
					<p class="small bg-info pb-2 pt-1 text-light">
						<span><?php the_category(', '); ?> ||</span>
						<span><?php the_time('_F d, Y__g:iA'); ?> ||</span>
						<span>Posted by <?php the_author(); ?></span>
					</p>
				</div>
				<div class="col-12">
					<?php the_post_thumbnail('custom-image-size', array('class' => 'w-100 h-auto')); ?>
					<p class="small mt-1">
						<span class="fab fa-facebook-messenger"></span>
						<span><?php comments_number(); ?></span>
						<span><?php the_time('_F d, Y'); ?></span>
					</p>
				</div>
				<div class="col-12">
					<div class="tags small mb-3">
						<?php $tags = __('This Post Tags: ', 'bussness'); ?>
						<?php the_tags( $tags, '', '' );; ?>
					</div>
				</div>
				<div class="col-12">
					<p class="text-justify mb-1">
						<?php the_content(); ?>
					</p>
				</div>
			</div>
		</div>
		
		<?php get_template_part( 'template-part/navigation' ); ?>

		<!-- comment area -->
		<div class="col-12 my-3">
			<?php 
						if( ( is_single() || is_page() ) && ( comments_open() || get_comments_number() ) && ! post_password_required() ) :
				comments_template();
			endif;
					 ?>
		</div>
	</div>
</div>
