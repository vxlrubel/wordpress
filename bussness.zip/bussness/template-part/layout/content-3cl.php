<?php 

get_sidebar();
get_template_part( 'template-part/content', 'right-sidebar' );
get_template_part( 'template-part/layout/content', get_post_type() );
