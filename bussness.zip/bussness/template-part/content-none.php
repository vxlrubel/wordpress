<div>
	<h3 class="mb-3 py-3">
		<?php 
			printf( __( 'No Post Available.', 'bussness' ) );
		 ?>
	</h3>
	<p>
		<span class="d-block mb-2">
			<?php 
				printf( __( 'You may create a post.', 'bussness' ) );
			 ?>
		</span>
		<a href="<?php echo esc_url( home_url( '/wp-admin/post-new.php' ) ); ?>" class="create-post">
			<?php 
				printf( __( 'Create Post', 'bussness' ) );
			 ?>
		</a>
	</p>
</div>