
<?php global $bussness; ?>

	<footer class="footer clearfix bg-dark text-light py-4" id="smoothlst">
		<div class="container-fluid text-dark">
			<?php 
				// login form
				do_action( 'bussness_login_form' );

				// create new user
				do_action( 'bussness_create_new_user' );
				
				// reset password
				do_action( 'bussness_reset_password' );

			 ?>
		</div>

		<div class="container-fluid mb-4">
			<div class="row">
			<?php BSS()->layout->footer_sidebars(); ?>
			</div>
		</div>

		<div class="container-fluid">
			<div class="row">
				<div class="col-12 footer-top-visibility">
					<div class="row">
						<?php BSS()->layout->headquarters(); ?>
						
						<?php BSS()->layout->contact(); ?>

						<?php BSS()->layout->subscribe(); ?>
					</div>
				</div>

				<div class="col-12 bg-dark">
					<p class="fa_copyright_text_visibility pt-2 font-weight-bold text-<?php echo $bussness['fa_copyright_position']; ?>">
						<?php echo $bussness['fa_copyright_text']; ?>
					</p>
				</div>
			</div>
		</div>

		<!-- scroll to top -->
		<div class="scroll_top">
			<a href="#" class="scroll-top">
				<?php scroll_top_icon_change(); ?>
			</a>
		</div>

	</footer>

	<?php wp_footer(); ?>
</body>
</html>
