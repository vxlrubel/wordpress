<?php 
/**
 * Template Name: Contact
 */
 ?>
<?php get_header(); ?>

	<section class="clearfix">
		<div class="container-fluid">
			<?php if ( have_posts() ): ?>
				<?php while( have_posts() ) : the_post(); ?>
					<div class="row bg-dark">
						<div class="col-md-6" style="background-image: url(<?php the_post_thumbnail_url(); ?>);  background-size: cover;"></div>
						
						<div class="col-md-6">
							<?php the_content(); ?>
						</div>
					</div>
				<?php endwhile; ?>
			<?php endif ?>
		</div>
	</section>

<?php get_footer(); ?>