<?php 
get_header();
	do_action( 'section_before' );

		$theme_inside_layout = $bussness['tl_layout_inside'];

		if( $theme_inside_layout == 1) : 
			get_sidebar();
			if (have_posts()) :
				while(have_posts()) : the_post();
				get_template_part( 'template-part/content', 'single' );
				endwhile;
			endif;
			get_template_part( 'template-part/content', 'right-sidebar' );

		elseif( $theme_inside_layout == 2) : 
			get_template_part( 'template-part/layout/2cl/content', 'sidebar' );
			if (have_posts()) :
				while(have_posts()) : the_post();
				get_template_part( 'template-part/layout/content', 'single' );
				endwhile;
			endif;

		elseif( $theme_inside_layout == 3) : 
			if (have_posts()) :
				while(have_posts()) : the_post();
				get_template_part( 'template-part/layout/content', 'single' );
				endwhile;
			endif;
			get_template_part( 'template-part/layout/2cl/content', 'sidebar' );


		elseif( $theme_inside_layout == 4) : 
			get_sidebar();
			get_template_part( 'template-part/content', 'right-sidebar' );
			if (have_posts()) :
				while(have_posts()) : the_post();
				get_template_part( 'template-part/content', 'single' );
				endwhile;
			endif;

		elseif( $theme_inside_layout == 5) : 
			if (have_posts()) :
				while(have_posts()) : the_post();
				get_template_part( 'template-part/content', 'single' );
				endwhile;
			endif;
			get_sidebar();
			
			get_template_part( 'template-part/content', 'right-sidebar' );

		endif;
		wp_reset_postdata();

	do_action( 'section_after' );


get_footer();

