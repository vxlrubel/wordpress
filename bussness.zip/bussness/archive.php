<?php get_header(); ?>
	<section class="clearfix">
		<div class="container-fluid">
			<div class="row">
				<?php get_sidebar(); ?>
				<div class="col-6 mb-2">
					<div class="row">
						<?php if (have_posts()): ?>
							<div class="col-12">
								<ul class="list-unstyled">
									<?php while ( have_posts() ) : the_post(); ?>
									  <li class="media mb-5">
									    <?php the_post_thumbnail( 'archive', ['class' => 'mr-3']); ?>
									    <div class="media-body">
									    	<a href="<?php the_permalink(); ?>" class="text-decoration-none text-dark">
									    		<?php the_title( '<h5 class="mt-0 mb-1">', '</h5>', true ); ?>
									    	</a>
									      <p>
									      	<?php wp_trim( 15 ); ?>
									      </p>
												<div class="tags">
													<?php the_tags( ' ', '', '' ); ?>
												</div>
									    </div>
									  </li>
									<?php endwhile; ?>
								</ul>
							</div>
						<?php endif; ?>
					</div>
				</div>
				<?php get_template_part( 'template-part/content', 'right-sidebar' ); ?>
			</div>
		</div>
	</section>



<?php get_footer(); ?>