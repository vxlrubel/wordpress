<?php 

if ( !class_exists( 'Bss_Theme_Options' ) ) {
	class Bss_Theme_Options {
		public function visibility_options() {
			global $bussness;
			$dis = $bussness['footer-top-area-visibility'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'footer-top-visibility', $dis );

			$dis = $bussness['headquarters-visibility'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'headquarters-visivility', $dis );

			$dis = $bussness['contact-visibility'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'contact-visibility', $dis );

			$dis = $bussness['subscribe-visibility'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'subscribe-visibility', $dis );

			$dis = $bussness['ht_visibility'] > 0 ? 'block' : 'none';
			bss_dis_cls( 'header-top', $dis );
			
			$dis = $bussness['cds_social'] >0 ? 'flex' : 'none !important';
			bss_dis_cls( 'socila-icon-list', $dis );
			
			$dis = $bussness['cds_date'] > 0 ? 'flex' : 'none !important';
			bss_dis_cls( 'date-visiblity', $dis );

			$dis = $bussness['hm_visibility'] > 0 ? 'block' : 'none';
			bss_dis_cls( 'logo', $dis );
			
			$dis = $bussness['hm_menu_visibility'] > 0 ? 'flex' : 'none';
			bss_dis_cls( 'nav', $dis );

			$dis = $bussness['bo_breadcrumb'][0] > 0 ? 'block' : 'none !important';
			bss_dis_cls( 'breadcrumb-visibility', $dis );

			$dis = $bussness['ticker'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'ticker-visibility', $dis );

			$dis = $bussness['so_visibility']>0 ? 'block' : 'none !important';
			bss_dis_cls( 'carousel-slider', $dis );

			$dis = $bussness['fp_all_visibility'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'feature-visibility', $dis );

			$dis = $bussness['fp_all_title_visibility'] > 0 ? 'block' : 'none';
			bss_dis_cls( 'feature-title-visibility', $dis );

			$dis = $bussness['fp_all_visibility_left'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'feature-left-visibility', $dis );

			$dis = $bussness['fp_all_visibility_middle'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'feature-center-visibility', $dis );

			$dis = $bussness['fp_all_visibility_right'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'feature-right-visibility', $dis );

			$dis = $bussness['st_check'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'static-visibility', $dis );

			$dis = $bussness['atb_srv_section_visibility'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'atb_srv_section_visibility', $dis );

			$dis = $bussness['atb_srv_title_visible'] > 0 ? 'block' : 'none';
			bss_dis_cls( 'atb_srv_title_visible', $dis );

			$dis = $bussness['atb_srv_description_visible'] > 0 ? 'block' : 'none';
			bss_dis_cls( 'atb_srv_description_visible', $dis );

			$dis = $bussness['atb_abt_section_visibility'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'atb_abt_section_visibility', $dis );

			$dis = $bussness['atb_abt_title_visible'] > 0 ? 'block' : 'none';
			bss_dis_cls( 'atb_abt_title_visible', $dis );

			$dis = $bussness['atb_abt_description_visible'] > 0 ? 'block' : 'none';
			bss_dis_cls( 'atb_abt_description_visible', $dis );

			$dis = $bussness['scroll_top'][0] > 0 ? 'block' : 'none';
			bss_dis_cls( 'scroll_top', $dis );

			$dis = $bussness['fa_copyright_text_visibility'] > 0 ? 'block' : 'none';
			bss_dis_cls( 'fa_copyright_text_visibility', $dis );

			$dis = $bussness['preloader_visibility'][1] > 0 ? 'block' : 'none';
			bss_dis_id( 'af-preloader', $dis );
		}

		public function nav_menu_positions(){
			global $bussness;
			$position = $bussness['hm_menu_position'];
			bss_style( ['class' => 'nav'], [
				css_property( 'justify-content', $position )
			] );
		}
		public function dropdown_animation_effects(){
			global $bussness;
			$effects = $bussness['hm_menu_drpdown_effect']. ' .5s linear both';
			bss_style( ['class' => 'dropdown'], [
				css_property( 'animation', $effects )
			] );
		}

		public function scroll_up_btn_position(){
			global $bussness;
			$c = 'color: ';
			$b = 'border: ';
			$bg = 'background: ';
			$color = $bussness['scroll_top_color'];
			$background = $bussness['scroll_top_bg'];
			$border = $bussness['scroll_top_border_color'];
			$s = '; ';
			$end = "}\n";
			$position = $bussness['scroll_top_position'];
			echo '.scroll-top {';
			if ( 1 == $position ) : echo 'top: 30px;left: 30px;';
			elseif ( 2 == $position ) : echo 'top: 30px;left: 50%;margin-left: -15px;';
			elseif ( 3 == $position ) : echo 'top: 30px;right: 30px;';
			elseif ( 4 == $position ) : echo 'bottom: 30px;left: 30px;';
			elseif ( 5 == $position ) : echo 'bottom: 30px;left: 50%;margin-left: -15px;';
			elseif ( 6 == $position ) : echo 'bottom: 30px;right: 30px;';
			endif;
			echo $c. $color. $s;
			echo $bg. $background. $s;
			echo $b. '1px solid '.$border. $end;

			$top_left = 1 == $position ? '30px' : '';
			$hover_color = $bussness['scroll_top_color_hover'];
			$hover_background = $bussness['scroll_top_bg_hover'];
			$hover_border = $bussness['scroll_top_border_hover_color'];
			echo '.scroll-top:hover {';
			echo $c. $hover_color. $s;
			echo $bg. $hover_background. $s;
			echo $b. '1px solid '.$hover_border. $end;
		}

		public function background_change(){
			global $bussness;
			$bgc = $bussness['bo_breadcrumb_clr'];
			bss_background_color( 'breadcrumb-visibility', $bgc );

			$bgc = $bussness['fp_all_title_bg_color'];
			bss_background_color( 'feature-title-visibility', $bgc );
		}

		public function project_color_change(){
			global $bussness;
			$change_color = $bussness['fp_all_title_color'];
			bss_color( 'feature-title-visibility', $change_color );

			$change_color = $bussness['atb_srv_title_clr'];
			bss_color( 'atb_srv_title_visible', $change_color );

			$change_color = $bussness['atb_srv_description_clr'];
			bss_color( 'atb_srv_description_visible', $change_color );

			$change_color = $bussness['atb_abt_title_clr'];
			bss_color( 'atb_abt_title_visible', $change_color );

			$change_color = $bussness['atb_abt_description_clr'];
			bss_color( 'atb_abt_description_visible', $change_color );

			$change_color = $bussness['fa_copyright_color'];
			bss_color( 'fa_copyright_text_visibility', $change_color );

			$change_color = $bussness['preloader_color_id'];
			echo ".af-sp-wave:before, .af-sp-wave:after { border-color: $change_color }";
		}

	}
}