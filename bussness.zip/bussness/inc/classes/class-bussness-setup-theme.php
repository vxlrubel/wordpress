<?php 

/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness Theme
 * @subpackage Bussness_Setup_Theme
 * @since 1.1.0
 * @see create Bussness_Setup_Theme class
 */

class Bussness_Setup_Theme {

	public $post;

	public $preloader;

	public $sidebars;

	public $theme;

	public $layout;

	public $frontpage;

	public $options;

	public function __construct() {

		$this->post = new Bussness_Post();

		$this->sidebars = new Bussness_Sidebars();

		$this->preloader = new Bussness_Preloader_Options();

		$this->theme = new Bussness_Theme_Content();

		$this->layout = new Bussness_Layout_Content();

		$this->frontpage = new Bussness_Frontpage_Content();

		$this->options = new Bss_Theme_Options();
	}

}

/**
 * @see Require Class Bussness_Post
 */

require_once dirname(__FILE__) . './class-bussness-post.php';

/**
 * @see Require Class Bussness_Sidebars
 */
require_once dirname(__FILE__) . './class-bussness-preloader-options.php';

/**
 * @see Require Class Bussness_Preloader_Options
 */
require_once dirname(__FILE__) . './class-bussness-sidebars.php';

/**
 * @see Require Class Bussness_Theme_Content
 */
require_once dirname(__FILE__) . './class-bussness-theme-content.php';

/**
 * @see Require Class Bussness_Layout_Content
 */
require_once dirname(__FILE__) . './class-bussness-layout-content.php';

/**
 * @see Require Class Bussness_Frontpage_Content
 */
require_once dirname(__FILE__) . './class-bussness-frontpage-content.php';

/**
 * @see Require Class Bss_Theme_Options
 */
require_once dirname(__FILE__) . './class-bss-theme-options.php';
