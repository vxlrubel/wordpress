<?php 

/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage Bussness_Theme_Content
 * @since 1.1.0
 * @see Class Bussness_Theme_Content 
 */

class Bussness_Theme_Content {

	public function logo() { ?>
		<?php global $bussness; ?>
		<div class="logo">
			<a href="<?php echo esc_url(home_url('/')); ?>">

				<img src="<?php echo $bussness['hm_logo_upload']['url']; ?>" alt="logo image">
			</a>
		</div>

		<?php 
	}

	public function primary_menu() {
		if(has_nav_menu( 'primary-menu' )) :
			wp_nav_menu(array(
				'theme_location'  => 'primary-menu',
				'container'       => '',
				'menu_class'      => 'menu',
				'walker'          => new Bussness_Nav_Menu()
			));
		else:
			wp_page_menu( array( 
				'menu_class'      => 'all-page',
			 ));
		endif;
	}

	public function float_menu() {
		if ( has_nav_menu( 'float-menu' ) ) {
			echo '<div class="list-float d-none d-md-block">';
			wp_nav_menu(array(
				'theme_location'  => 'float-menu',
				'container'       => '',
				'menu_class'      => 'left-popup-menu',
				'walker'          => new Bussness_Nav_Menu()
			));
			echo '</div>';
		}
	}

	public function breadcrumb() { ?>
		<div class="bread-crumb">
			<?php 
			breadcrumb_trail(array(
				'show_browse'     => false,
			));
			 ?>
		</div>
		<?php 
	}

	public function ticker() { ?>
		<?php global $bussness; ?>

		<div class="col-12">
			<div class="exclusive">
				<span>EXCLUSIVE</span>
				<span class="ticker-loading"></span>
			</div>
			<div class="ticker">
				<?php
				if( $bussness['ticker_text'] ) :
					echo '<p class="text-light m-0">'.$bussness['ticker_text'].'</p>';
				else:
				$ticker = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' => -1
				));
				if ( $ticker->have_posts() ):
					$count = 1;
					while( $ticker->have_posts() ) : $ticker->the_post();
				 ?>

						<div class="ticker-image">
							<?php the_post_thumbnail(); ?>
						</div>
						<div class="ticker-title">
							<a href="<?php the_permalink(); ?>" class="text-decoration-none text-light">
								<?php 
								echo $count++.'. ';
								the_title();
								 ?>
							</a>
						</div>
						<?php
					endwhile;
				 endif;
				endif;
				 ?>
			</div>
		</div>
	<?php 
	}

}