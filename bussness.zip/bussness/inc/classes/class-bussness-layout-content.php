<?php 

/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage Bussness_Layout_Content
 * @since 1.1.0
 * @see Class Bussness_Layout_Content 
 */
class Bussness_Layout_Content {

	public function social_icon() {
		global $bussness; ?>
		<div class="socila-icon d-flex h-100">
			<ul class="socila-icon-list d-flex h-100 m-0 align-items-center list-unstyled justify-content-center w-100">

				<?php 
				if ($bussness['sil_list_facebook']){
					echo '<li><a href="'.$bussness['sil_list_facebook'].'"><span class="fab fa-facebook-f"></span></a></li>';
				}
				if ($bussness['sil_list_skype']){
					echo '<li><a href="'.$bussness['sil_list_skype'].'"><span class="fab fa-skype"></span></a></li>';
				}
				if ($bussness['sil_list_twitter']) {
					echo '<li><a href="'.$bussness['sil_list_twitter'].'"><span class="fab fa-twitter"></span></a></li>';
				}
			   if ($bussness['sil_list_linkedin']) {
					echo '<li><a href="'.$bussness['sil_list_linkedin'].'"><span class="fab fa-linkedin-in"></span></a></li>';
			   }
				if ($bussness['sil_list_reedit']) {
					echo '<li><a href="'.$bussness['sil_list_reedit'].'"><span class="fab fa-reddit"></span></a></li>';
				}

				 ?>
			</ul>
		</div>
		<?php 
	}

	public function footer_sidebars() { 

			$before = "<div class=\"col-md-3\"> \n";
			$before .= "<div class=\"row\"> \n";
			$after = "</div> \n";
			$after .= "</div> \n";

			echo $before;
			dynamic_sidebar( 'footer-widget1' );
			echo $after;
			
			echo $before;
			dynamic_sidebar( 'footer-widget2' );
			echo $after;
			
			echo $before;
			dynamic_sidebar( 'footer-widget3' );
			echo $after;

			echo $before;
			dynamic_sidebar( 'footer-widget4' );
			echo $after;
	}

	public function headquarters() { ?>
		<?php global $bussness; ?>
		<div class="col-md-3 headquarters-visivility">
			<h3 class="footer-title"><?php echo $bussness['headquarters-title']; ?></h3>
			<ul class="list-unstyled">
				<?php if ( $bussness['headquarters-phone'] ): ?>
				<li class="footer-list">
					<span class="fas fa-phone"></span>
					<span class="ml-1"><?php echo $bussness['headquarters-phone']; ?></span>
				</li>
				<?php endif; ?>
				<?php if ( $bussness['headquarters-email'] ): ?>
					<li class="footer-list">
						<span class="far fa-envelope"></span>
						<span class="ml-1"><?php echo $bussness['headquarters-email']; ?></span>
					</li>
				<?php endif; ?>
				<?php if ( $bussness['headquarters-address'] ): ?>
					<li class="footer-list">
						<span class="fas fa-location-arrow"></span>
						<span class="ml-1"><?php echo $bussness['headquarters-address']; ?></span>
					</li>
				<?php endif; ?>
			</ul>
		</div>
		<?php 
	}
	public function contact() { ?>
		<?php global $bussness; ?>
		<div class="col-md-6 contact-visibility">
			<h3 class="footer-title"><?php echo $bussness['contact-us-footer']; ?></h3>

				<?php 
					$contact = new WP_Query(array(
						'post_type' => 'custom_contact',
						'posts_per_page' => -1
					));
					if($contact-> have_posts()) :
						while($contact-> have_posts()) : $contact-> the_post(); 
							the_content();
						endwhile;
					endif;
				 ?>
		</div>
		<?php 
	}

	public function subscribe() { ?>
		<?php global $bussness; ?>
		<div class="col-md-3 subscribe-visibility">
			<h3 class="footer-title"><?php echo $bussness['subscribe-us-title']; ?></h3>
			<form action="#" method="post">
				<input class="subscribe-email" type="email" required="" placeholder="Email Address">
				<button class="subscribe" type="submit">
					<?php $label = '<span class="fab fa-telegram-plane"></span>'; ?>
					<?php echo $bussness['subscribe-us-label'] ? $bussness['subscribe-us-label'] : $label; ?>
					
					</button>
			</form>
		</div>
		<?php 
	}


}