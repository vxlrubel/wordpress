<?php 
/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage Bussness_Preloader_Options
 * @since 1.1.0
 * @see Class Bussness_Preloader_Options 
 */
 
class Bussness_Preloader_Options {

	/**
	 * @see preloader weve
	 */
	public function wave() {
		$preloader = '<div id="af-preloader"><div class="af-preloader-wrap"><div class="af-sp af-sp-wave"> </div></div></div>';
		echo $preloader;
	}

	/**
	 * @see preloader ajax_loader
	 */
	public function ajax_loader() {
		$ajax_loader = '<div class="ajax-loader">';
		$ajax_loader .= '<span class="drop-1"></span>';
		$ajax_loader .= '<span class="drop-2"></span>';
		$ajax_loader .= '<span class="drop-3"></span>';
		$ajax_loader .= '</div>';
		echo $ajax_loader;
	}

	/**
	 * @see preloader ajax_door
	 */
	public function ajax_door() {
		$ajax_door = '<div class="ajax-door">';
		$ajax_door .= '<div class="door-left "></div>';
		$ajax_door .= '<div class="door-right "></div>';
		$ajax_door .= '<div class="spin-door"></div>';
		$ajax_door .= '</div>';
		echo $ajax_door;
	}

	/**
	 * @see preloader ajax_grow
	 */
	public function ajax_grow() {
		$ajax_grow = '<div class="ajax-grow">';
		$ajax_grow .= '<div class="grow"></div>';
		$ajax_grow .= '</div>';
		echo $ajax_grow;
	}

	/**
	 * @see preloader ajax_loading
	 */
	public function ajax_loading() {
		$ajax_loading = '<div class="ajax-loading">';
		$ajax_loading .= '<button class="loading-btn" disabled>';
		$ajax_loading .= '<span class="spin"></span>';
		$ajax_loading .= '<span class="loading">Loading...</span>';
		$ajax_loading .= '</button>';
		$ajax_loading .= '</div>';
		echo $ajax_loading;
	}

	/**
	 * @see preloader ajax_load
	 */
	public function ajax_load() {
		$ajax_load = '<div class="ajax-load">';
		$ajax_load .= '<div class="load-box">';
		$ajax_load .= '<div class="loading">';
		$ajax_load .= '<div class="load"></div>';
		$ajax_load .= '</div>';
		$ajax_load .= '</div>';
		$ajax_load .= '</div>';
		echo $ajax_load;
	}

	/**
	 * @see preloader ajax_hack
	 */
	public function ajax_hack() {
		$ajax_hack = '<div class="ajax-hack">';
		$ajax_hack .= '<div class="hack-spin1">';
		$ajax_hack .= '<div class="hack-spin2">';
		$ajax_hack .= '</div>';
		$ajax_hack .= '</div>';
		$ajax_hack .= '</div>';
		echo $ajax_hack;
	}

}