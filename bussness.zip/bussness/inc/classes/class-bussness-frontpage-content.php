<?php 
/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage Bussness_Frontpage_Content
 * @since 1.1.0
 * @see Class Bussness_Frontpage_Content 
 */
class Bussness_Frontpage_Content {

	public function feature_post() {
		global $bussness; ?>

		<div class="row">
			<div class="col-12">
				<h4 class="feature-title-visibility m-0 py-3 text-<?php echo $bussness['fp_all_title_position']; ?>">
				<?php echo $bussness['fp_all_title_text']; ?>
				</h4>
			</div>
			<div class="col-md-3">
				<div class="bs-slick feature-left-visibility">
					<?php 
					$slick_post = new WP_Query(array(
						'post_type' => 'post',
						'posts_per_page' => -1
					));
					if($slick_post-> have_posts()) :
						while($slick_post-> have_posts()) : $slick_post-> the_post(); 
					?>
					
					<div class="bs-slick-box">
						<p class="pt-3 text-light small">
							<?php the_category(', '); ?>
							<?php bss_link( get_permalink(), get_the_title(), 'text-decoration-none text-light d-block h5' ); ?>
						</p>
					</div>

					<?php 
						endwhile;
					endif;
					 ?>
				</div>
			</div>
			<div class="col-md-5">
				<div class="bs-slick-slider feature-center-visibility">
				<?php 
				$bs_slick = new WP_Query(array(
					'post_type' => 'post',
					'posts_per_page' => 5,
					'order' => 'DSC'
				));
				if($bs_slick-> have_posts()) :
					while($bs_slick-> have_posts()) : $bs_slick-> the_post();
				?>

					<div class="bs-slick-slider-box">
						<div class="bs-slick-thumb">
							<?php the_post_thumbnail( 'slick' ); ?>
						</div>
						<div class="bs-slick-content">
							<h2>
								<?php bss_link( get_permalink(), get_the_title(), 'text-decoration-none' ); ?>
							<p><?php wp_trim(10); ?></p>
						</div>
					</div>
				<?php 
					endwhile;
				endif;
				 ?>
				</div>
			</div>
			<div class="col-md-4 right-swipe-up">
				<div class="bs-slick-right feature-right-visibility">
					<?php 
					$slick_right_post = new WP_Query(array(
						'post_type' => 'post',
						'posts_per_page' => -1
					));
					if($slick_right_post-> have_posts()) :
						while($slick_right_post-> have_posts()) : $slick_right_post-> the_post(); 
					?>

					<div class="bs-slick-box">
						<?php bss_post_thumbnail( 'slick-thumb', 'slick-image' ); ?>
						<?php bss_link( get_permalink(), get_the_title(), 'd-block h5 mt-2 m-0 text-light text-decoration-none' ); ?>
						<span class="text-white d-block small">
							<?php wp_trim(10); ?>
						</span>
					</div>
					<?php 
						endwhile;
					endif;
					 ?>						
				</div>
			</div>
		</div>

		<?php 
	}

	public function carousel_unic() {
		global $bussness; ?>
		<div class="row unic owl-carousel unic-width">
			<?php 
				$unic_slider = new WP_Query([
					'post_type' => 'post',
					'posts_per_page' => 5
				]);
			 ?>
			<?php if ( $unic_slider-> have_posts() ): ?>
			<?php while ( $unic_slider-> have_posts() ) : $unic_slider-> the_post(); ?>
				<div class="col-12 text-center descriptions" style="background-image: url(<?php the_post_thumbnail_url(); ?>); background-size: cover">
					<div class="description">
						<?php the_title('<h2 class="text-capitalize">', '</h2>'); ?>
						<?php wp_trim( 35 ); ?>
					</div>
					<div class="background-gradient"></div>
				</div>
			<?php endwhile; ?>
			<?php endif; ?>
		</div>
		<div class="row unic-down owl-carousel unic-width">
			<?php while ( $unic_slider-> have_posts() ) : $unic_slider-> the_post(); ?>
				<div class="col">
					<div class="media">
						<?php bss_post_thumbnail( 'unic-width', 'img-fluid' ); ?>
						<div class="unic-down-title">
							<?php bss_link( get_permalink(), __( 'More Details', 'bussness' ) ); ?>
						</div>
					</div>
				</div>
			<?php endwhile; ?>
		</div>

		<?php 
	}

	public function services() {
		global $bussness; ?>

		<div class="row">
			<div class="col-12 text-center">

				<h2 class="text-uppercase atb_srv_title_visible">
					<?php echo $bussness['atb_srv_title']; ?>
				</h2>
				<p class="atb_srv_description_visible">
					<?php echo $bussness['atb_srv_description']; ?>
				</p>
			</div>

			<?php
			$service = new WP_Query(array(
				'post_type' => 'services',
				'posts_per_page' => 4
			));
			 if ($service -> have_posts()):
				while($service -> have_posts()) : $service -> the_post(); ?>
			<!-- single services -->
			<div class="col-md-3 col-sm-6">
				<div>
					<?php bss_post_thumbnail( 'service' ); ?>
				</div>
				<div class="mb-3">
					<a href="<?php the_permalink(); ?>" class="h5 text-decoration-none"><?php the_title(); ?></a>
					<span class="d-block small"><?php the_time('_F d, Y') ?></span>
				</div>
			</div>
			<?php endwhile;
			 endif; ?>
		</div>

		<?php 
	}

	public function about() {
		global $bussness; ?>

		<div class="row">
			<div class="col-12 text-center">
				<h2 class="text-uppercase atb_abt_title_visible">
					<?php echo $bussness['atb_abt_title']; ?>
				</h2>
				<p class="atb_abt_description_visible">
					<?php echo $bussness['atb_abt_description']; ?>
				</p>
			</div>

			<!-- single about -->
			<?php 
			$about = new WP_Query(array(
				'post_type' =>'about',
				'post_per_page' => -1
			));
			if ($about -> have_posts()) {
				while($about -> have_posts()) : $about -> the_post();
					get_template_part( 'template-part/content', 'about' );
				endwhile;
			}
			 ?>
		</div>

		<?php 
	}
	
	public function isotop() {
		global $bussness; ?>

		<div class="row">
			<div class="col-12">
				<h2>Isotop Dynamic</h2>
				<p>This is the isotop area. You may add some isotop from here, If you want.</p>
			</div>
			<div class="col-12">
				<div class="control">
					<select class="drop">
						<?php bss_option( 'all', 'All' ); ?>
						<?php 
							$terms = get_terms('portfolio');
							foreach ( $terms as $term ) :
								echo '<option value=".'.$term->slug.'">'.$term->name.'</option>';
							endforeach;
						 ?>
					</select>
		      <select class="sort">
		      	<?php bss_option( 'default:asc', 'Ascending' ); ?>
		      	<?php bss_option( 'default:desc', 'Descending' ); ?>
		      </select>
				</div>
			</div>
			<div class="col-12">
				
				<div class="content">
					<?php 
						$isotop = new WP_Query(array(
							'post_type' => 'portfolios',
							'taxonomy' => 'portfolio',
							'posts_per_page' => -1,
						));
					 ?>
					<?php if ( $isotop-> have_posts()): ?>
						<?php while( $isotop-> have_posts() ) : $isotop-> the_post(); ?>
							<?php 
								$terms = get_the_terms( get_the_ID(), 'portfolio' );
								if ( $terms && ! is_wp_error( $terms ) ) {
									$db_name = array();
									foreach ( $terms as $term ) {
										$db_name[] = $term->name;
										$slug = $term->slug;								
										$link = esc_url( get_term_link( $term, 'portfolio' ) ); ?>
											<div class="mix <?php echo $slug; ?>">
												<?php bss_post_thumbnail(); ?>
												<div class="files">
													<?php bss_link( get_permalink(), get_the_title(), 'btn btn-sm btn-primary' ); ?>
												</div>
											</div>
										<?php 
									}
									$drought = join(',', $db_name);
								}

							 ?>
						<?php endwhile; ?>
					<?php endif; ?>

				</div>
			</div>
		</div>

		<?php 
	}
	
}