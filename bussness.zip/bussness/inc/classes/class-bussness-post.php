<?php 

/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage Bussness_Post
 * @since 1.1.0
 * @see Class Bussness_Post 
 */

class Bussness_Post {

	public function related_post() {
		global $post;
		$original_post = '';
		$categories = get_the_category( $post->ID );

		if ( $categories ) {

			$category_ids = array();
			foreach ( $categories as $individual_category ) {
				$category_ids[] = $individual_category->term_id;
			}
			$args = array(
				'category__in' => $category_ids,
				'post__not_in' => array( $post->ID ),
				'posts_per_page' => 4,
				'ignore_sticky_posts' => 1,
				'post_type' => 'post',
			);
			$related_post_query = new wp_query( $args );

			if ( $related_post_query->have_posts() ) { ?>
				<div class="col-12 mb-3">
					<h4 class="text-uppercase">related POST</h4>
				</div>
				
				<?php 

				while ( $related_post_query->have_posts() ) {
					$related_post_query->the_post(); ?>

						<div class="col-md-3 mb-3">
							<div class="relative-post">
								<div class="thumb">
									<a href="<?php the_permalink(); ?>" class="d-none">
										<?php
										$categories = get_the_terms( $post->ID, 'category' );
										foreach ( $categories as $category ) {
											  $link = get_category_link( $category->term_id );
											  echo '<mark class="catagory">' . esc_html( $category->name ) . '</mark>';
										} ?>
										<?php the_title(); ?>
									</a>
									<?php the_post_thumbnail(); ?>
								</div>
								<div class="relative-post-title">
									<a href="<?php the_permalink(); ?>">Read More &gt;</a>
								</div>
							</div>
						</div>

					<?php
				}
			}
		}

		wp_reset_postdata();
	}

	public function share_btn() { ?>
		<a href="https://www.facebook.com/sharer?u=&lt;<?php the_permalink();?>&gt;&amp;t=&lt;<?php the_title(); ?>&gt;" target="_blank" rel="noopener noreferrer" title="Share on Facebook">
			<span class="fab fa-facebook-f"></span>
		</a>

		<a href="http://twitter.com/intent/tweet?text=Currently reading &lt;<?php the_title(); ?>&gt;&amp;url=&lt;<?php the_permalink(); ?>&gt;" target="_blank" rel="noopener noreferrer" title="Share on Twitter">
			<span class="fab fa-twitter"></span>
		</a>

		<a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=&lt;<?php the_permalink(); ?>&gt;&amp;title=&lt;<?php the_title(); ?>&gt;&amp;summary=&amp;source=&lt;<?php bloginfo('name'); ?>&gt;" target="_new" rel="noopener noreferrer">
			<span class="fab fa-linkedin" title="Share on LinkedIn">
		</a>
		
		<?php 
	}

	public function comments_popup_link() {
		$zero = __( 'No Comment', 'bussness' );
		$one = __( '1 Comment', 'bussness' );
		$more = __( '% Comments', 'bussness' );
		$css_class = 'comments-popup';
		comments_popup_link( $zero, $one, $more, $css_class );
	}


}