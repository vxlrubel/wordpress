<?php 
/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage Bussness_Sidebars
 * @since 1.1.0
 * @see Class Bussness_Sidebars 
 */

class Bussness_Sidebars {

	protected $default_options = [
		'before_widget' => '<div class="col-12 widget">',
		'after_widget'  => "</div>\n",
		'before_title'  => '<h5 class="capitalize">',
		'after_title'   => "</h5>\n"
	];

	protected $footer_options = [
		'before_widget' => "<div class=\"col-12\"><div class=\"footer-widget\"> \n",
		'after_widget'  => "</div></div>\n",
		'before_title'  => '<h2 class="footer-widget-title">',
		'after_title'   => "</h2>\n"
	];

	public function left() {
		$sidebar_options = [
			'name'          => __('Bussness Sidebar 1', 'bussness'),
			'id'            => 'bussness-sidebar',
			'description'   => __('Drag the widget\'s item and drop here', 'bussness')
		];
		register_sidebar( array_merge( $this->default_options, $sidebar_options ) );
	}

	public function right() {
		$sidebar_options2 = [
			'name'          => __('Bussness Sidebar 2', 'bussness'),
			'id'            => 'bussness-sidebar-second',
			'description'   => __('Drag the widget\'s item and drop here', 'bussness')
		];
		register_sidebar( array_merge( $this->default_options, $sidebar_options2 ) );
	}

	public function footer1() {
		$footer_widget1 = [
			'name'          => __('Footer Widget 1', 'bussness'),
			'id'            => 'footer-widget1',
			'description'   => __('Drag the widget\'s item and drop here', 'bussness')
		];
		register_sidebar( array_merge( $this->footer_options, $footer_widget1 ) );
	}

	public function footer2() {
		$footer_widget2 = [
			'name'          => __('Footer Widget 2', 'bussness'),
			'id'            => 'footer-widget2',
			'description'   => __('Drag the widget\'s item and drop here', 'bussness')
		];
		register_sidebar( array_merge( $this->footer_options, $footer_widget2 ) );
	}

	public function footer3() {
		$footer_widget3 = [
			'name'          => __('Footer Widget 3', 'bussness'),
			'id'            => 'footer-widget3',
			'description'   => __('Drag the widget\'s item and drop here', 'bussness')
		];
		register_sidebar( array_merge( $this->footer_options, $footer_widget3 ) );
	}

	public function footer4() {
		$footer_widget4 = [
			'name'          => __('Footer Widget 4', 'bussness'),
			'id'            => 'footer-widget4',
			'description'   => __('Drag the widget\'s item and drop here', 'bussness')
		];
		register_sidebar( array_merge( $this->footer_options, $footer_widget4 ) );
	}

}