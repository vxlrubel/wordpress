<?php 

	
/**
 * @see Register taxonomy like category..
 */

add_action( 'init', 'bussness_taxonomy_category' );

if( !function_exists( 'bussness_taxonomy_category' ) ):

	// clrate new category
	function bussness_taxonomy_category(){
		$labels = [
			'name'              => __( 'Categories', 'bussness'),
			'singular_name'     => __( 'Category', 'bussness'),
			'search_items'      => __( 'Search Categories', 'bussness' ),
			'all_items'         => __( 'All Categories', 'bussness' ),
			'parent_item'       => __( 'Parent Category', 'bussness' ),
			'parent_item_colon' => __( 'Parent Categories:', 'bussness' ),
			'edit_item'         => __( 'Edit Category', 'bussness' ),
			'update_item'       => __( 'Update Category', 'bussness' ),
			'add_new_item'      => __( 'Add New Category', 'bussness' ),
			'new_item_name'     => __( 'New Category Name', 'bussness' ),
			'menu_name'         => __( 'Categories', 'bussness' ),
		];

		$args = [
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'categorie' ),
		];

		register_taxonomy( 'categorie', ['about', 'services',], $args );
		register_taxonomy( 'portfolio', ['portfolios'], $args );

	}
endif;


/**
 * @see Register taxonomy like tags..
 */

add_action( 'init', 'bussness_taxonomy_tags' );

if( !function_exists( 'bussness_taxonomy_tags' ) ):

	// clrate new tag
	function bussness_taxonomy_tags(){
		$labels = array(
			'name'              => __( 'Keywords', 'bussness'),
			'singular_name'     => __( 'Keyword', 'bussness'),
			'search_items'      => __( 'Search Keywords', 'bussness' ),
			'all_items'         => __( 'All Keywords', 'bussness' ),
			'parent_item'       => __( 'Parent Keyword', 'bussness' ),
			'parent_item_colon' => __( 'Parent Keywords:', 'bussness' ),
			'edit_item'         => __( 'Edit Keyword', 'bussness' ),
			'update_item'       => __( 'Update Keyword', 'bussness' ),
			'add_new_item'      => __( 'Add New Keyword', 'bussness' ),
			'new_item_name'     => __( 'New Keyword Name', 'bussness' ),
			'menu_name'         => __( 'Keywords', 'bussness' ),
		);

		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'keyword' ),
		);

		register_taxonomy( 'keyword', ['about', 'services',], $args );
		register_taxonomy( 'tags', ['portfolios'], $args );
		

	}
endif;