<?php 
/**
 *  @see Author Class Flipslide
 */
class Author_Flip_Slide extends WP_Widget{
	public function __construct() {
		$options = array(
			'description'                 => __( 'Flip Slide Using by post thumbnail.', 'bussness' ),
		);
		parent::__construct( 'author-flip-slide', __( 'BS:: Flipslider', 'bussness' ), $options );
	}
	public function widget( $args, $instance ) {
		$title = ! empty($instance['title']) ? $instance['title'] : __('Flipslider', 'bussness');
			 echo $args['before_widget'];
			 echo $args['before_title']. $title .$args['after_title'];
			 ?>
			<div class="owl-carousel widget-slider">
				<?php 
					$flipSlide = new WP_Query([
						'post_type' => 'post',
						'posts_per_page' => -1
					]);
				 ?>
				 <?php if ( $flipSlide-> have_posts() ) : ?>
				 	<?php while ( $flipSlide-> have_posts() ) : $flipSlide-> the_post(); ?>
					<p><a href="<?php the_permalink('flip-slide'); ?>">
						<?php the_post_thumbnail(); ?>
					</a></p>
				 	<?php endwhile; ?>
				 <?php endif; ?>
			</div>
		   <?php 
			echo $args['after_widget']; 
	}

	public function form( $instance ) {
			$title = $instance['title'];
			?>
			<p>
				<label for="<?php echo $this-> get_field_id('title'); ?>">Title</label>
				<input class="widefat" type="text" name="<?php echo $this-> get_field_name('title'); ?>" value="<?php echo $title; ?>" id="<?php echo $this-> get_field_id('title'); ?>">
			</p>

			<?php 
	}
	public function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		return $instance;
	}

}