<?php 

/**
 * Author info tags
 */
class Author_Info_Iags extends WP_Widget{
	public function __construct(){
		$options = array(
			'description' => __('All tags list here, you can add this widgets item any sidebar')
		);
		parent::__construct('author-info-tags', __('BS:: Tags', 'bussness'), $options);
	}
	public function widget($args, $instance){

		$title = ! empty($instance['title']) ? $instance['title'] : __('Tags List', 'bussness');
		echo $args['before_widget'];
			echo $args['before_title'].$title.$args['after_title'];
			wp_tag_cloud(array(
				'number'     => 45,
			));
		echo $args['after_widget'];
	}

	public function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		return $instance;
	}

	public function form($instance){
		$title = $instance['title'];
	 ?>
		<p>
			<label for="<?php echo $this-> get_field_id('title'); ?>">Title</label>
			<input class="widefat" type="text" name="<?php echo $this-> get_field_name('title'); ?>" id="<?php echo $this-> get_field_id('title'); ?>" value="<?php echo $title; ?>">
		</p>

		<?php 
	}
}


// tags style
function author_info_tag(){ ?>

	<style type="text/css" media="screen">
		.tag-cloud-link{
			background: #66BC7B;
			border: 1px solid #66BC7B;
			border-radius: 3px;
			color: #222;
			padding: 1px 3px;
			margin: 0 3px 5px 0;
			font-size: 8pt !important;
			text-decoration: none !important;
			transition: all .4s
		}
		.tag-cloud-link:hover{
			background: #fff;
			color: #66BC7B;
		}
	</style>
	<?php 
}
add_action('wp_head', 'author_info_tag');