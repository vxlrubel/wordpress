<?php

class Author_Info_Categories extends WP_Widget {

	public function __construct() {
		$options = array(
			'description'                 => __( 'A list of widget of categories.', 'bussness' ),
		);
		parent::__construct( 'author-info-categories', __( 'BS:: Categories', 'bussness' ), $options );
	}

	public function widget( $args, $instance ) {
		$title = ! empty($instance['title']) ? $instance['title'] : __('Categories', 'bussness');
			 echo $args['before_widget'];
			 echo $args['before_title'].$title.$args['after_title'];
			 ?>

			<div class="widget-content">
				<?php wp_list_categories(array(
					'separator' => ' ',
					'style'     => 'div',
				)); ?>
			</div>
		   <?php 
			echo $args['after_widget']; 

	}
	public function form( $instance ) {
			$title = $instance['title'];
			?>
			<p>
				<label for="<?php echo $this-> get_field_id('title'); ?>">Title</label>
				<input class="widefat" type="text" name="<?php echo $this-> get_field_name('title'); ?>" value="<?php echo $title; ?>" id="<?php echo $this-> get_field_id('title'); ?>">
			</p>

			<?php 
	}
	public function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		return $instance;
	}

}
function author_info_categories_scripts(){ ?>
	<script type="text/javascript">
		(function($){
			var inside_widget = '.widget-content>a';
			$(inside_widget).addClass('w-100 d-block text-decoration-none bg-light py-1 text-dark');
		})(jQuery);
	</script>
	<?php 
}
add_action('wp_footer', 'author_info_categories_scripts');
