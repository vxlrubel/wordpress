<?php 

/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage ALL WIDGET REQUIRE
 * @since 1.1.0
 * @see All Widget Class are included in this file.
 */

/**
 *  @see Widgets of  class Author_Flip_Slide.
 */
require_once dirname(__FILE__) . './class-author-flipslide.php';

/**
 *  @see Widgets of  class Author_Info_Categories.
 */
require_once dirname(__FILE__) . './class-author-info-categories.php';

/**
 *  @see Widgets of  class Author_Info_Gallery.
 */
require_once dirname(__FILE__) . './class-author-info-gallery.php';

/**
 *  @see Widgets of  class Author_Info_Iags.
 */
require_once dirname(__FILE__) . './class-author-info-tags.php';

/**
 *  @see Widgets of  class Author_Information.
 */
require_once dirname(__FILE__) . './class-author-information.php';

/**
 *  @see Widgets of  class Author_Swipe_Up.
 */
require_once dirname(__FILE__) . './class-author-swipe-up.php';