<?php 

class Author_Info_Gallery extends WP_Widget{
	public function __construct(){
		parent::__construct( 'author-info-gallery', __('BS:: Gallery', 'bussness'), array( 
			'description' => __( 'You can use the widget and see latest post\'s image gallery.', 'bussness')
		) );
	}

	public function widget( $args, $instance ){
		$title = ! empty( $instance['title'] ) ? $instance['title'] : __('Latest Post Gallery', 'bussness');
		echo $args['before_widget'];
		echo $args['before_title'].$title. $args['after_title'];
		$gallery_post = new WP_Query( array(
			'post_type' 	  => 'post',
			'posts_per_page' => 9,
			'order'			  => 'DSC'
		) );
		echo '<div class="galleris">';
		if($gallery_post-> have_posts()):
			while($gallery_post-> have_posts()) : $gallery_post-> the_post();
				?>
					<a href="<?php the_permalink(); ?>">
						<?php the_post_thumbnail('squire'); ?>
					</a>

				<?php 
			endwhile;
		endif;
		echo '</div>';
		echo $args['after_widget'];
	}

	public function form( $instance ){
		$title = $instance['title'];
		echo '<p><label for="'.$this-> get_field_id( 'title' ).'">Title:</label>';
		echo '<input type="text" name="'.$this-> get_field_name( 'title' ).'" value="'.$title.'" class="widefat" id="'.$this-> get_field_id( 'title' ).'"></p>';
	}

	public function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance[ 'title' ] = $new_instance[ 'title' ];
		return $instance;
	}
	
}