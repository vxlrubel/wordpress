<?php 

class Author_Information extends WP_Widget{
	public function __construct(){
	parent::__construct('author-info', __( 'BS:: Information', 'bussness' ), array(
		'description' => __('Author information box with title, image and details.', 'bussness')
	));
	}

	public function widget($args, $instance){
		if ($instance['title']) {
			$title = $instance['title'];
		}
		if ($instance['author-uploaded-image']) {
			$image = '<img src="'.$instance['author-uploaded-image'].'" alt="widget-image">';
		}
		if ($instance['name']) {
			$name = '<span class="d-block">Name : '.$instance['name'].'</span>';
		}
		if ($instance['company']) {
			$company = '<span class="d-block">Company : '.$instance['company'].'</span>';
		}
		if ($instance['designation']) {
			$designation = '<span class="d-block">Designation : '.$instance['designation'].'</span>';
		}
		if ($instance['description']) {
			$description = '<span class="d-block">Designation : '.$instance['description'].'</span>';
		}
		
		echo $args['before_widget'];
			echo $args['before_title']. $title.$args['after_title']; 
		?>
			<div>
				<?php echo $image; ?>
			</div>
			<div class="widget-content small">
				 <?php 
				 echo $name;
				 echo $company;
				 echo $designation;
				 echo $description; 
				 ?>
				
			</div>
		<?php echo $args['after_widget']; ?>


		<?php 
	}


	public function form($instance){
		$title = $instance['title'];
		$image = $instance['author-uploaded-image'];
		$name = $instance['name'];
		$company = $instance['company'];
		$designation = $instance['designation'];
		$description = $instance['description'];
		?>

		<!-- author title -->
		<p>
			<label for="<?php echo $this-> get_field_id( 'title' ); ?>">Title</label>
			<input type="text" class="widefat" id="<?php echo $this-> get_field_id( 'title' ); ?>" name="<?php echo $this-> get_field_name( 'title' ); ?>" value="<?php echo $title; ?>">
		</p>
			
		<!-- author image -->
		<p>
			<button class="button author_image_upload_btn">Upload Author Image</button>
			<input type="hidden" value="" class="widefat author_image_uploaded_link" name="<?php echo $this-> get_field_name('author-uploaded-image') ?>" value="<?php echo $image; ?>">
			<img src="<?php echo $image; ?>" alt="image" class="widefat author_image_uploaded_src">
		</p>

		<!-- author name -->
		<p>
			<label for="<?php echo $this-> get_field_id( 'name' ); ?>">Name:</label>
			<input type="text" class="widefat" id="<?php echo $this-> get_field_id( 'name' ); ?>" name="<?php echo $this-> get_field_name( 'name' ); ?>" value="<?php echo $name; ?>">
		</p>

		<!-- author company -->
		<p>
			<label for="<?php echo $this-> get_field_id( 'company' ); ?>">Company:</label>
			<input type="text" class="widefat" id="<?php echo $this-> get_field_id( 'company' ); ?>" name="<?php echo $this-> get_field_name( 'company' ); ?>" value="<?php echo $company; ?>">
		</p>

		<!-- author designation -->
		<p>
			<label for="<?php echo $this-> get_field_id( 'designation' ); ?>">Designation</label>
			<input type="text" class="widefat" id="<?php echo $this-> get_field_id( 'designation' ); ?>" name="<?php echo $this-> get_field_name( 'designation' ); ?>" value="<?php echo $designation; ?>">
		</p>

		<!-- author description -->
		<p>
			<label for="<?php echo $this-> get_field_id( 'description' ); ?>">Description:</label>
			<textarea class="widefat" name="<?php echo $this-> get_field_name( 'description' ); ?>" id="<?php echo $this-> get_field_id( 'description' ); ?>">
				<?php echo $description; ?>
			</textarea>
		</p>

		<?php 
	}

	public function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		$instance['author-uploaded-image'] = $new_instance['author-uploaded-image'];
		$instance['name'] = $new_instance['name'];
		$instance['company'] = $new_instance['company'];
		$instance['designation'] = $new_instance['designation'];
		$instance['description'] = $new_instance['description'];

		return $instance;
	}

}
