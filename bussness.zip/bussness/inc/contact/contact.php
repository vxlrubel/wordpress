<?php 
class Bussness_25802580_Contact_form {

    /**
     * Class constructor
     */
    public function __construct() {

        $this->bussness_contact_hook();
    }

    public function controller() {

        if( isset( $_POST['submit'] ) ) { // Submit button

            $full_name   = filter_input( INPUT_POST, 'full_name', FILTER_SANITIZE_STRING );
            $email       = filter_input( INPUT_POST, 'email', FILTER_SANITIZE_STRING | FILTER_SANITIZE_EMAIL );
            $comments    = filter_input( INPUT_POST, 'comments', FILTER_SANITIZE_STRING );

            // Send an email and redirect user to "Thank you" page.
        }
    }

    /**
     * Display form
     */
    public function display_form() {

        $full_name   = filter_input( INPUT_POST, 'full_name', FILTER_SANITIZE_STRING );
        $email       = filter_input( INPUT_POST, 'email', FILTER_SANITIZE_STRING | FILTER_SANITIZE_EMAIL );
        $comments    = filter_input( INPUT_POST, 'comments', FILTER_SANITIZE_STRING );

        // Default empty array
        $output = '';

        $output .= '<form method="post">';
        $output .= $this->display_text( 'full_name', 'Name', $full_name );
        $output .= $this->display_text( 'email', 'Email', $email );
        $output .= $this->display_textarea( 'comments', 'comments', $comments );
        $output .= '<input class="subscribe mb-2" type="submit" name="submit" value="Sent Message" />';
        $output .= '</form>';

        return $output;
    }

    /**
     * Display text field
     */
    private function display_text( $name, $label, $value = '' ) {

        $output = '';

        $output .= '<input required id="contact-name" placeholder="'.$label.'" type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';

        return $output;
    }

    /**
     * Display textarea field
     */
    private function display_textarea( $name, $label, $value = '' ) {

        $output = '';
        $output .= '<textarea required class="text-area" placeholder="'.$label.'" name="' . esc_attr( $name ) . '" >' . esc_html( $value ) . '</textarea>';

        return $output;
    }

    /**
     * Define hooks related to plugin
     */
    private function bussness_contact_hook() {

        /**
         * Add action to send email
         */
        add_action( 'wp', array( $this, 'controller' ) );

        /**
         * Add shortcode to display form
         */
        add_shortcode( 'contact', array( $this, 'display_form' ) );
    }
}

new Bussness_25802580_Contact_form();