<?php 

add_action('wp_enqueue_scripts', 'bussness_theme_script_and_style');
if(! function_exists('bussness_theme_script_and_style')) :
	function bussness_theme_script_and_style(){

		// bussness theme style
		wp_enqueue_style( 'font-awesome', get_template_directory_uri(). '/lib/font/css/fontawesome-all.min.css', array(), false, 'all' );

		wp_enqueue_style( 'bootstrap', get_template_directory_uri(). '/lib/bootstrap/bootstrap.css', array('font-awesome'), false, 'all' );

		wp_enqueue_style( 'carousel', get_template_directory_uri(). '/lib/carousel/css/owl.carousel.css', array('font-awesome', 'bootstrap'), false, 'all' );

		wp_enqueue_style( 'carousel-theme', get_template_directory_uri(). '/lib/carousel/css/owl.theme.default.css', array('font-awesome', 'bootstrap', 'carousel'), false, 'all' );

		wp_enqueue_style( 'slick', get_template_directory_uri(). '/lib/slick/slick.css', array('font-awesome', 'bootstrap', 'carousel', 'carousel-theme'), false, 'all' );

		wp_enqueue_style( 'slick-theme', get_template_directory_uri(). '/lib/slick/slick-theme.css', array('font-awesome', 'bootstrap', 'carousel', 'carousel-theme', 'slick'), false, 'all' );

		wp_enqueue_style( 'fancybox', get_template_directory_uri(). '/lib/fancybox/fancybox.css', array('font-awesome', 'bootstrap', 'carousel', 'carousel-theme', 'slick', 'slick-theme'), false, 'all' );
		wp_enqueue_style( 'main-style', get_template_directory_uri(). '/lib/custom/css/main.css', array('font-awesome', 'bootstrap', 'carousel', 'carousel-theme', 'slick', 'slick-theme', 'fancybox'), false, 'all' );

		wp_enqueue_style( 'style', get_stylesheet_uri(), array('font-awesome', 'bootstrap', 'carousel', 'carousel-theme', 'slick', 'slick-theme', 'fancybox', 'main-style'), false, 'all' );

		wp_enqueue_style( 'responsive', get_template_directory_uri(). '/lib/custom/css/responsive.css', array('font-awesome', 'bootstrap', 'carousel', 'carousel-theme', 'slick', 'slick-theme', 'fancybox', 'main-style', 'style'), false, 'all' );

		// bussness theme script
		wp_enqueue_script('jquery');

		wp_enqueue_script( 'bootstrap', get_theme_file_uri( 'lib/bootstrap/bootstrap.js' ), array( 'jquery' ), false, false );

		wp_enqueue_script( 'carousel', get_theme_file_uri( 'lib/carousel/js/owl.carousel.js' ), array( 'jquery', 'bootstrap' ), false, false );

		wp_enqueue_script( 'ticker', get_theme_file_uri( 'lib/ticker/ticker.js' ), array( 'jquery', 'bootstrap', 'carousel' ), false, false );

		wp_enqueue_script( 'slick', get_theme_file_uri( 'lib/slick/slick.js' ), array( 'jquery', 'bootstrap', 'carousel', 'ticker' ), false, false );

		wp_enqueue_script( 'smooth-scroll', get_theme_file_uri( 'lib/smooth-scroll/jquery.nav.js' ), array( 'jquery', 'bootstrap', 'carousel', 'ticker', 'slick' ), false, false );

		wp_enqueue_script( 'mixit', get_theme_file_uri( 'lib/mixitup/mixitup.js' ), array( 'jquery', 'bootstrap', 'carousel', 'ticker', 'slick' ), false, false );

		wp_enqueue_script( 'fancybox', get_theme_file_uri( 'lib/fancybox/fancybox.js' ), array( 'jquery', 'bootstrap', 'carousel', 'ticker', 'slick', 'mixit' ), false, false );

		wp_enqueue_script( 'script', get_theme_file_uri( 'lib/custom/js/script.js' ), array( 'jquery', 'bootstrap', 'carousel', 'ticker', 'slick', 'mixit', 'fancybox' ), false, false );

		wp_enqueue_script( 'java', get_theme_file_uri( 'lib/javascripts.js' ), array( 'jquery', 'bootstrap', 'carousel', 'ticker', 'slick', 'mixit', 'fancybox', 'script' ), true, true );

		if( is_singular()) wp_enqueue_script( 'comment-reply' );
	}
endif;