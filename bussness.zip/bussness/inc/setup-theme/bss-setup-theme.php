<?php 
/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage ALL SETUP FILE REQUIRE
 * @since 1.1.0
 * @see All setup file are included in this file.
 */


/**
 * @see Enqueue file are inlcuded
 */
require_once dirname(__FILE__) . './bussness-enqueue-scripts.php';

/**
 * @see Theme options are inlcuded
 */
require_once dirname(__FILE__) . './bussness-options.php';

/**
 * @see Theme scripts are inlcuded
 */
require_once dirname(__FILE__) . './bussness-scripts.php';

/**
 * @see all menus are inlcuded
 */
require_once dirname(__FILE__) . './class-bussness-nav-menu.php';

/**
 * @see Build in class restyle file are inlcuded
 */
require_once dirname(__FILE__) . './restyle-wordpress-class.php';

/**
 * @see Custom functions file are inlcuded
 */
require_once dirname(__FILE__) . './template.php';