<?php 

add_filter( 'comment_form_default_fields', 'redefine_comments_form_fields' );

function redefine_comments_form_fields( $fields ){
	unset( $fields['author'] );
	unset( $fields['email'] );
	unset( $fields['url'] );
	$fields = [
		'author' => '<p class="comment-field-inline"><input class="something" type="text" name="author" value="" placeholder="Name"></p>',
		'email' => '<p class="comment-field-inline" style="text-align:right"><input type="email" name="email" value="" placeholder="Email Address"> </p>'
	];
	return $fields;
}

add_filter( 'comment_form_fields', 'wpba_comment_textarea_bottom' );

function wpba_comment_textarea_bottom( $fields ){
	$comment_form = $fields['comment'];
	unset( $fields['comment'] );
	$fields['comment'] = $comment_form;
	return $fields;
}
add_action('after_setup_theme', 'bussness_setup_functions');

function bussness_setup_functions(){
	if (! function_exists('wp_trim')) {
		function wp_trim( $limit ){
		echo wp_trim_words( get_the_content(), $limit, ' [...]' );
		}
	}

	// get_field_value from custom field
	if (! function_exists('wp_option')) {
		function wp_option( $fieldID ){
		echo get_post_meta( get_the_ID(), $fieldID, true );
		}
	}
}



/**
 * Filter Classes of wp_list_pages items to match menu items.
 * Filter the class applied to wp_list_pages() items with children to match the menu class, to simplify.
 * styling of sub levels in the fallback. Only applied if the match_menu_classes argument is set.
 *
 * @param array  $css_class CSS Class names.
 * @param string $item Comment.
 * @param int    $depth Depth of the current comment.
 * @param array  $args An array of arguments.
 * @param string $current_page Whether or not the item is the current item.
 *
 * @return array $css_class CSS Class names.
 */

add_filter( 'page_css_class', 'bs_filter_wp_list_pages_item_classes', 10, 5 );

function bs_filter_wp_list_pages_item_classes( $css_class, $item, $depth, $args, $current_page ) {

	// Only apply to wp_list_pages() calls with match_menu_classes set to true.
	$match_menu_classes = isset( $args['match_menu_classes'] );

	if ( ! $match_menu_classes ) {
		return $css_class;
	}

	// Add current menu item class.
	if ( in_array( 'current_page_item', $css_class, true ) ) {
		$css_class[] = 'active';
	}

	// Add menu item has children class.
	if ( in_array( 'page_item_has_children', $css_class, true ) ) {
		$css_class[] = 'menu-item-has-children';
	}

	return $css_class;

}

/**
 * Filter comment reply link to not JS scroll.
 * Filter the comment reply link to add a class indicating it should not use JS slow-scroll, as it
 * makes it scroll to the wrong position on the page.
 *
 * @param string $link Link to the top of the page.
 *
 * @return string $link Link to the top of the page.
 */
add_filter( 'comment_reply_link', 'bs_filter_comment_reply_link' );

function bs_filter_comment_reply_link( $link ) {

	$link = str_replace( 'class=\'', 'class=\'do-not-scroll ', $link );
	return $link;

}

/**
 * @see scroll to top icon's class name.
 * @return clase name
 */
if ( !function_exists( 'scroll_top_icon_change' ) ):
	function scroll_top_icon_change(){
		global $bussness;
		$icon = $bussness['scroll_top_icon'];
		echo '<span class="';
		if( 1 == $icon ) : echo 'fas fa-arrow-circle-up';
		elseif( 2 == $icon ) : echo 'far fa-arrow-alt-circle-up';
		elseif( 3 == $icon ) : echo 'far fa-caret-square-up';
		elseif( 4 == $icon ) : echo 'fas fa-angle-double-up';
		elseif( 5 == $icon ) : echo 'fas fa-angle-up';
		elseif( 6 == $icon ) : echo 'fas fa-arrow-alt-circle-up';
		elseif( 7 == $icon ) : echo 'fas fa-long-arrow-alt-up';
		elseif( 8 == $icon ) : echo 'fas fa-arrow-up';
		elseif( 9 == $icon ) : echo 'fas fa-caret-square-up';
		elseif( 10 == $icon ) : echo 'fas fa-caret-up';
		elseif( 11 == $icon ) : echo 'fas fa-chevron-circle-up';
		elseif( 12 == $icon ) : echo 'fas fa-chevron-up';
		elseif( 13 == $icon ) : echo 'fas fa-level-up-alt';
		endif;
		echo '"></span>';
	}
endif;

/**
 * @see basic label tag
 */
if ( !function_exists( 'bss_label' ) ) {
	function bss_label( $for, $content = '' ){
		$label = '<label for="' . esc_attr( $for ) . '">' . esc_html( $content ) . '</label>';
		echo $label;
	}
}
/**
 * @see basic input tag for require
 */
if ( !function_exists( 'bss_input_r' ) ) {
	function bss_input_r( $type = 'text', $name = '', $class = '', $id = '', $require = 'true' ){
		$input = '<input type="'.esc_attr( $type ).'" name="'.esc_attr( $name ).'" required="'.esc_attr( $require ).'" class="'.esc_attr( $class ).'" id="'.esc_attr( $id ).'">';
		echo $input;
	}
}
/**
 * @see basic inout tag
 */
if ( !function_exists( 'bss_input' ) ) {
	function bss_input( $type = 'text', $name = '', $class = '', $id = '' ){
		$input = '<input type="'.esc_attr( $type ).'" name="'.esc_attr( $name ).'" class="'.esc_attr( $class ).'" id="'.esc_attr( $id ).'">';
		echo $input;
	}
}

/**
 * @see basic option tag
 */

if ( !function_exists( 'bss_option' ) ) {
	function bss_option( $value, $label, $selected = null ){
		$selected == null ? $selected = '' : $selected = 'selected="' . esc_attr( 'selected' ) . '"';
		$option = '<option '.$selected.' value="' . esc_attr( $value ) . '">' . esc_html( $label ) . '</option>';
		echo $option;
	}
}
/**
 * @see basic link
 */
if ( !function_exists( 'bss_link' ) ) {
	function bss_link( $href, $label, $css_class = null ) {
		$css_class == null ? $css_class = '' : $css_class = ' class="'. esc_attr( $css_class ) .'"';
		$link = '<a href="' . esc_url( $href ) . '"' . $css_class . ' >' . esc_html( $label ) . '</a>';
		echo $link;
	}
}
/**
 * @see bss_post_thumbnail
 */

if ( !function_exists( 'bss_post_thumbnail' ) ) {
	function bss_post_thumbnail( $post_thumb = null, $css_classes = null ) {
		$post_thumb == null ? $post_thumb = '' : $post_thumb = $post_thumb;
		$css_classes == null ? $css_classes = '' : $css_classes = ['class' => $css_classes];
		the_post_thumbnail( $post_thumb, $css_classes );
	}
}

/**
 * @see bss_color property and value with seleector
 */
if ( !function_exists( 'bss_color' ) ) {
	function bss_color( $selector_class_name, $value ) {
		$color = ".$selector_class_name { color: $value }\n";
		echo $color;
	}
}

/**
 * @see bss_background_color property and value with seleector
 */
if ( !function_exists( 'bss_background_color' ) ) {
	function bss_background_color( $selector_class_name, $value ) {
		$color = ".$selector_class_name { background-color: $value }\n";
		echo $color;
	}
}

/**
 * @see bss_dis_cls display property with class name
 */
if ( !function_exists( 'bss_dis_cls') ) {
	function bss_dis_cls( $class_name, $value ) {
		$display = ".$class_name { display: $value } \n";
		echo $display;
	}
}

/**
 * @see bss_dis_id display property with id name
 */
if ( !function_exists( 'bss_dis_id') ) {
	function bss_dis_id( $id_name, $value ) {
		$display = "#$id_name { display: $value } \n";
		echo $display;
	}
}


/**
 * @see bss_visibility display properties
 */
if ( !function_exists( 'bss_visibility' ) ) {
	function bss_visibility( $selector = [], $visibility ) {
		$selector = [
			'tag' => $selector['tag'],
			'class' => $selector['class'],
			'id' => $selector['id'],
			'attr' => $selector['attr'],
		];
		$tag = !empty( $selector['tag'] ) ? $selector['tag'] : '';
		$class = !empty( $selector['class'] ) ? '.' . $selector['class'] : '';
		$id = !empty( $selector['id'] ) ? '#' . $selector['id'] : '';
		$attr = !empty( $selector['attr'] ) ? '[' . $selector['attr'] . ']' : '';
		$selected = $tag . $class . $id . $attr;
		$visible = "$selected {\n";
		$visible .= "display: $visibility }";
		echo $visible;
	}
}

/**
 * @see css_property
 */
if ( !function_exists( 'css_property' ) ) {
	function css_property( $property, $value ) {
		return "$property: $value;\n";
	}
}

if ( !function_exists( 'bss_custom_value' ) ) {
	function bss_custom_value( $value ) {
		echo $value;
	}
}

if ( !function_exists( 'bss_style' ) ) {
	function bss_style( $selector, $property_value = [] ) {
		$selector = [
			'tag' => $selector['tag'],
			'class' => $selector['class'],
			'id' => $selector['id'],
			'attr' => $selector['attr'],
		];
		$select = !empty( $selector['tag'] ) ? $selector['tag'] : '';
		$select .= !empty( $selector['class'] ) ? '.' . $selector['class'] : '';
		$select .= !empty( $selector['id'] ) ? '#' . $selector['id'] : '';
		$select .= !empty( $selector['attr'] ) ? '[' . $selector['attr'] . ']' : '';
		echo "$select {";
		foreach ($property_value as $key ) {
			echo $key;
		}
		echo "}\n";
	}
}