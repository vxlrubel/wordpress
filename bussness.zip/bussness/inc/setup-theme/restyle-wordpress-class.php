<?php 

add_action('wp_head', 'bussness_wordpress_class_restyle');
if(! function_exists('bussness_wordpress_class_restyle')) : 
	function bussness_wordpress_class_restyle(){
		?>
		<style type="text/css" media="screen">
			/*category*/
			a[rel='category tag']{
			  color: #f8f9fa;
			  text-decoration: none !important;
			}
			a[rel='category tag']:hover{
			  color: #cbd3da;
			}
			.latest-post-category a[rel='category tag']{
			  color: #222;
			}
			/*calender*/
			#wp-calendar {
			  width: 100%;
			  border-collapse: collapse;
			  background: transparent;
			}
			#wp-calendar > caption{
			  background: #888;
			  color: #fff;
			  padding: 5px 0;
			  font-weight: 700;
			  transition: all .2s;
			}
			#wp-calendar > caption:hover{
			  background: #66BC7B;
			  color: #222;
			}
			#wp-calendar > thead{
			  background: #66BC7B;
			  color: #fff;
			}
			#wp-calendar > thead>tr>th{
			  border: 1px solid #555;

			}
			#wp-calendar > tbody>tr>td{
			  border: 1px solid #66BC7B;
			  text-align: center;
			  color: #222;
			  /*background: #63fe1e;*/
			  transition: all .4s;
			}
			#wp-calendar > tbody>tr>td:hover{
			  background: #66BC7B;
			  color: #fff;
			}
			#wp-calendar > tbody>tr>td>a{
			  color: #fff;
			  text-decoration: none !important;
			  background: #66BC7B;
			  display: block;
			  transition: all .4s;
			  font-weight: 700;
			}
			#wp-calendar > tbody>tr>td>a:hover{
			  color: #66BC7B;
			  background: #fff;
			}

			#wp-calendar > tfoot{
			  background: #66BC7B;
			  color: #222;
			}
			#wp-calendar > tfoot td{
			  border: 1px solid #555;
			}
			#prev{
			  background: #fff;
			}
			#next{
			  background: #fff;
			  text-align: right;
			}
			#prev>a,
			#next>a{
			  text-decoration: none !important;
			  color: #222;
			  font-weight: 700;
			}
			#prev>a:hover,
			#next>a:hover{
			  color: #66BC7B;
			}
			.page-list-widget{
				list-style: none;
			}
			
			/*start comments*/
			.comments-box label{
			  display: block;
			  cursor: pointer;
			}
			.comments-box label[for='wp-comment-cookies-consent']{
			  display: inline-block;
			  margin-left: 3px;
			  cursor: pointer;
			}
			#comment{
			  width: 100%;
			  height: 100px;
			  border: 1px solid #888;
			}
			.comments-box input{
			  border: 1px solid #888;
			}
			#comment:hover,
			#comment:focus,
			.comments-box input:hover,
			.comments-box input:focus{
			  border: 1px solid #66BC7B;
			}
			#cs_form_submit {
			  background: #66BC7B;
			  width: 70px;
			  padding: 5px;
			  border: none;
			}
			li.comment{
			  list-style: none;
			}


			.comments-time a{
			  text-decoration: none !important;
			  padding: 2px 5px !important;
			  color: #0000006e;
			  font-style: italic;
			  cursor: text;
			}
			.comments-time .comment-edit-link{
				text-decoration: none !important;
				transition: all .3s;
				color: #66BC7B;
				font-style: normal;
				cursor: pointer;
			}
			.comments-time .comment-edit-link:hover{
				color: #262723;
			}
			.comment-reply a.comment-reply-link{
				background: #66BC7B;
				text-decoration: none !important;
				padding: 2px 10px;
				border-radius: 3px;
				color: #f8f9fa;
				border: 1px solid transparent;
				transition: all .3s;
				box-shadow: 3px 3px 3px #bfbfbf;
			}
			.comment-reply a.comment-reply-link:hover,
			.comment-reply .reply-focus{
				border: 1px solid #66BC7B !important;
				background: #fff !important;
				color: #66BC7B !important;
				box-shadow: 3px 3px 3px #00005 !important
			}
			a#cancel-comment-reply-link{
				background: #ff0578;
				border-radius: 3px;
				padding: 2px 10px;
				text-decoration: none !important;
				font-size: 10pt;
				color: #fff;
				font-weight: 700;
			}
			.comment .comment{
				/*margin-left: 30px;*/
			}
			/*end comment*/

			/*comment pagination*/
			.comments-napigation{
				padding: 10px 0;
				display: flex;
				align-items: center;
				justify-content: center;	
			}
			.comments-napigation>span,
			.comments-napigation>a{
				background: #f0f0f0;
				border-radius: 3px;
				height: 35px !important;
				width: 35px !important;
				text-align: center;
				display: flex;
				justify-content: center;
				align-items: center;
				margin-right: 3px;
				border: 1px solid #66BC7B;
				box-sizing: border-box;
				text-decoration: none !important;
				color: #66BC7B;
			}
			.comments-napigation>span.current,
			.comments-napigation>a:hover{
				border: 1px solid #66BC7B;
				background: #66BC7B;
				outline: 1px solid #66BC7B;
				color: #f8f9fa;
				border-radius: 0;
			}

			.comment-respond-floating {
				position: fixed;
				top: 50%;
				left: 50%;
				margin-left: -228px;
				z-index: 99999;
				background: white;
				padding: 10px;
				box-sizing: border-box;
				box-shadow: 5px 5px 5px #8f8f8f;
				border: 2px solid #66BC7B;
				border-radius: 5px;
			}
			.comment-respond-floating textarea{
				height: 50px !important;
			}
			.custom-overlay{
				z-index: 9999;
				position: fixed;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				background: #000000db;
			}
			.comment-author-details img{
				width: 50px;
			}
			.children .comment-author-details img{
				width: 40px;
			}
			.children .comments-content{
				font-size: 90%;
			}

			.comment-respond#respond{
				padding: 20px;
				border: 1px solid #66BC7B;
			}

			<?php if(is_user_logged_in()) : ?>
			.custom-text-comment{
				position: relative;
			}
			.custom-text-comment>label{
				position: absolute;
				top: -12.5px;
				left: 20px;
				padding: 0 5px;
				font-weight: 700;
				color: #222;
				border-left: 2px solid #66BC7B;
				border-right:2px solid #66BC7B;
				background: #fff;
			}
			@keyframes x-slide{
				0%,100%{
				transform: translateX(0);
				}
				50%{
				transform: translateX(50px);
				}
			}
			.custom-text-comment:hover label{
				color: #66BC7B;
				animation: x-slide .75s linear both;
			}
		<?php endif; ?>

		</style>

		<?php 
	}
endif;