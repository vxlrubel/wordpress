<?php 

if(! function_exists('bussness_theme_script')) :
	function bussness_theme_script(){
		?>
		<script type="text/javascript">
			(function($){
				$(document).ready(function(){
					$('.page-list-widget a').addClass('list-group-item list-group-item-action');
					
					$('.comment-reply a.comment-reply-link').on('click', function(){
						$('.comment-reply a.comment-reply-link').removeClass('reply-focus');
						$(this).addClass('reply-focus');
					});
					$('a#cancel-comment-reply-link').on('click', function(){
						$('.comment-reply a.comment-reply-link').removeClass('reply-focus');
					});

					// Set Author Name
					var getAuthor = $('.get_author').val();
					$('.set_author').text(getAuthor);

					// Set Author Link
					var getAuthorLink = $('.get_author_link').val();
					$('.set_author_link').attr('href', getAuthorLink);

					var getAvatar = $('.get_avatar').html();
					$('.profile-thumb').html( getAvatar );

				});

				
			})(jQuery);
		</script>
		<?php 
	}
endif;
add_action('wp_footer', 'bussness_theme_script');