<?php
/**
 * @see Theme Options 
 */


add_action( 'wp_head', 'bussness_theme_options' );

if ( !function_exists( 'bussness_theme_options' ) ) :
	function bussness_theme_options(){
		echo "<style type=\"text/css\" media=\"screen\"> \n";
		// nav menu position
		BSS()->options->nav_menu_positions();
		// scroll to top
		BSS()->options->scroll_up_btn_position();
		// dropdown effects
		BSS()->options->dropdown_animation_effects();
		// visibility options
		BSS()->options->visibility_options();
		// background change
		BSS()->options->background_change();
		// color change
		BSS()->options->project_color_change();

		echo "</style> \n";
	}
endif;




