<?php 
add_shortcode( 'slider', 'bussness_contact_shortcode' );
function bussness_contact_shortcode(){
	ob_start();
		do_action( 'section_before' ); ?>
		<div class="col-md-12">
			<div class="owl-carousel shortcode-slider">
				<?php get_template_part( 'template-part/content', 'slider' ); ?>
			</div>
		</div>
	<?php 
		do_action( 'section_after' );
	return ob_get_clean();
}
// missed post
add_shortcode( 'missed_post', 'bussness_missed_post' );

function bussness_missed_post(){
	ob_start();
	do_action( 'section_before' );
		get_template_part( 'template-part/content', 'missed-post' );
	do_action( 'section_acter' );
	return ob_get_clean();
}
add_filter( 'widget_text', 'do_shortcode' );