<?php 
/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage bss_callback_comments_list
 * @since 1.1.0
 * @see comments list callback
 */

if ( !function_exists( 'bss_callback_comments_list' ) ) :
	function bss_callback_comments_list( $comment, $args, $depth ){
		$author_name = esc_html( $comment->comment_author );
		if ( 'div' == $args['style'] ) {
			$tag = 'div';
			$add_below = 'comment';
		} else {
			$tag = 'li';
			$add_below = 'div-comment';
		}
		?>
  <<?php echo esc_attr( $tag ); ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID(); ?>">
		<?php if ( 'div' == $args['style'] ) : ?>
  <div id="div-comment-<?php comment_ID(); ?>" class="comment-body review-list">
	<?php endif; ?>
		<li class="media comment-item py-3 mb-3">
			<?php
			 if ( 0 != $args['avatar_size'] ) {
				echo get_avatar( $comment, $args['avatar_size'] );}
			?>
			<div class="media-body ml-3">
				<h5 class="m-0 text-uppercase">
					<?php echo( $author_name ); ?>
				</h5>
				<span class="small">
					<time datetime="<?php comment_time( 'c' ); ?>">
						<?php 
						 printf( wp_kses_post( '%1$s at %2$s', 'bussness' ), wp_kses_post( get_comment_date( '', $comment ) ), wp_kses_post( get_comment_time() ) );
						 ?>
					</time>
				</span>
				<p class="mb-1">
					<?php comment_text(); ?>
				</p>
				<p class="comments-link m-0 p-0">
					<?php
					edit_comment_link( __( 'Edit' ) );
					comment_reply_link( array_merge(
						$args,
						array(
							'add_below' => $add_below,
							'depth'     => $depth,
							'max_depth' => $args['max_depth']
						)));
					 ?>
				</p>
				<p class="modaretor">
					<?php 
					 if ( 0 == $comment->comment_approved ){
					 	esc_html_e( 'Your comment is awaiting moderation.', 'bussness' );
					 }
					 ?>
				</p>
			</div>
		</li>
		<?php if ( 'div' == $args['style'] ) : ?>
  </div>
			<?php
  endif;
	}
endif;