<?php 


/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage Include All Required files.
 * @since 1.1.0
 * @see ALL REQUIRED FILES
 */

// Theme setup file are included
require_once dirname(__FILE__) .'./setup-theme/bss-setup-theme.php';

// aAll widget are included
require_once dirname(__FILE__) .'./widget/bss-widgets.php';

// theme options framework
require_once dirname(__FILE__) .'./theme-options/ReduxCore/framework.php';

// theme options config
require_once dirname(__FILE__) .'./theme-options/config.php';

// custom fields here are included
require_once dirname(__FILE__) .'./custom-fields/functions.php';

// breadcrumbs
require_once dirname(__FILE__) .'./breadcrumbs/breadcrumbs.php';

// All hooks are included
require_once dirname(__FILE__) .'./hooks/bss-hooks.php';

// register taxonomy
require_once dirname(__FILE__) .'./taxonomy/register-taxonomy.php';

// register post type
require_once dirname(__FILE__) .'./post-type/register-post-type.php';

// tgm plugins activation
require_once dirname(__FILE__) .'./tgm/functions.php';

require_once dirname(__FILE__) .'./contact/contact.php';

require_once dirname(__FILE__) .'./shortcode/shortcode-contact-form.php';

require_once dirname(__FILE__) . './classes/class-bussness-setup-theme.php';

// comments callback
require_once dirname(__FILE__) . './callback/callback-comments-list.php';




