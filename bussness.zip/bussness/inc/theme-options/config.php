<?php

    /**
     * ReduxFramework Barebones Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "bussness";

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'submenu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Theme Options', 'bussness' ),
        'page_title'           => __( 'Theme Options', 'bussness' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '_options',
        // Page slug used to denote the panel
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        //'compiler'             => true,

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'light',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
    $args['admin_bar_links'][] = array(
        'id'    => 'redux-docs',
        'href'  => 'http://docs.reduxframework.com/',
        'title' => __( 'Documentation', 'bussness' ),
    );

    $args['admin_bar_links'][] = array(
        //'id'    => 'redux-support',
        'href'  => 'https://github.com/ReduxFramework/redux-framework/issues',
        'title' => __( 'Support', 'bussness' ),
    );

    $args['admin_bar_links'][] = array(
        'id'    => 'redux-extensions',
        'href'  => 'reduxframework.com/extensions',
        'title' => __( 'Extensions', 'bussness' ),
    );

    // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
    $args['share_icons'][] = array(
        'url'   => 'https://facebook.com/rubel.ft.me',
        'title' => 'Visit me on Facebook',
        'icon'  => 'el el-facebook'
        //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
    );
    $args['share_icons'][] = array(
        'url'   => 'https://twitter.com/rubel.ft.me',
        'title' => 'Like us on Twitter',
        'icon'  => 'el el-twitter'
    );
    $args['share_icons'][] = array(
        'url'   => 'https://linkedin.com/rubel.ft.me',
        'title' => 'Follow us on Linkedin',
        'icon'  => 'el el-linkedin'
    );
    $args['share_icons'][] = array(
        'url'   => 'https://skype.com/rubel.ft.me',
        'title' => 'Find us on Skype',
        'icon'  => 'el el-skype'
    );

    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( __( '<p>Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: <strong>$%1$s</strong></p>', 'bussness' ), $v );
    } else {
        $args['intro_text'] = __( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'bussness' );
    }

    // Add content after the form.
    $args['footer_text'] = __( '<p>This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.</p>', 'bussness' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'bussness' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'bussness' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'bussness' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'bussness' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'bussness' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */

    // -> START Basic Fields

    // theme layout
    Redux::setSection( $opt_name, array(
        'title'      => __('Theme Layout', 'bussness'),
        'id'         => 'theme-layout',
        'desc'       => __( 'General fields as subsections.', 'bussness' ),
        'icon'       => 'el el-website',
        'fields'     => array(
            array(
                'id'       => 'tl_layout',
                'type'     => 'image_select',
                // 'tiles'    => true,
                'title'    => __( 'Theme Outside Layout', 'bussness' ),
                'subtitle' => __( 'You can change the theme outdie layout here. ', 'bussness' ),
                'desc'     => __( 'You may change the theme outdie layout here. ', 'bussness' ),
                'options'  => array(
                    '1' => array(
                        'alt' => 'full-width',
                        'img' => get_template_directory_uri(). '/lib/img/theme-layout/full-width.jpg'
                    ),
                    '2' => array(
                        'alt' => 'box-width',
                        'img' => get_template_directory_uri(). '/lib/img/theme-layout/box-width.jpg'
                    )
                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'tl_layout_inside',
                'type'     => 'image_select',
                // 'tiles'    => true,
                'title'    => __( 'Theme Inside Layout', 'bussness' ),
                'subtitle' => __( 'You can change the theme inside layout here. ', 'bussness' ),
                'desc'     => __( 'You may change the theme inside layout here. ', 'bussness' ),
                'options'  => array(
                    '0' => array(
                        'alt' => 'Full Layout',
                        'img' => get_template_directory_uri(). '/lib/img/theme-layout/1col.png'
                    ),
                    '1' => array(
                        'alt' => 'Three Colum',
                        'img' => get_template_directory_uri(). '/lib/img/theme-layout/3cm.png'
                    ),
                    '2' => array(
                        'alt' => 'Left Sidebar',
                        'img' => get_template_directory_uri(). '/lib/img/theme-layout/2cl.png'
                    ),
                    '3' => array(
                        'alt' => 'Right Sidebar',
                        'img' => get_template_directory_uri(). '/lib/img/theme-layout/2cr.png'
                    ),
                    '4' => array(
                        'alt' => 'Three Colum Left Sidebar',
                        'img' => get_template_directory_uri(). '/lib/img/theme-layout/3cl.png'
                    ),
                    '5' => array(
                        'alt' => 'Three Colum Right Sidebar',
                        'img' => get_template_directory_uri(). '/lib/img/theme-layout/3cr.png'
                    )
                ),
                'default'  => '0'
            ),          
        )
    ) );

    // general options
    Redux::setSection( $opt_name, array(
        'title' => __( 'General Option', 'bussness' ),
        'id'    => 'general',
        'desc'  => __( 'General fields as subsections.', 'bussness' ),
        'icon'  => 'el el-home'
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Header Top', 'bussness' ),
        'desc'       => __( ' ', 'bussness'),
        'id'         => 'header-top',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'ht_visibility',
                'type'     => 'switch',
                'title'    => __( 'Header top visibility', 'bussness' ),
                'subtitle' => __( 'You may hide or show header top area.', 'bussness' ),
                'default'  => false
            ),
            array(
                'id'       => 'cds_phone',
                'type'     => 'text',
                'title'    => __( 'Phone Number', 'bussness' ),
                'subtitle' => __( 'You may add your phone number.', 'bussness' ),
                'desc'     => __( 'You may add or change your phone number.', 'bussness' ),
                'default'  => '0171-4240934',
                'required' => array( 'ht_visibility', '=', true )
            ),
            array(
                'id'       => 'cds_email',
                'type'     => 'text',
                'title'    => __( 'Email Address', 'bussness' ),
                'subtitle' => __( 'You may add your email addressr.', 'bussness' ),
                'desc'     => __( 'You may add or change your email address.', 'bussness' ),
                'default'  => 'vxlrubel@gmail.com',
                'required' => array( 'ht_visibility', '=', true )
            ),
            array(
                'id'       => 'cds_social',
                'type'     => 'checkbox',
                'title'    => __( 'Social Icon Visibility', 'bussness' ),
                'subtitle' => __( 'You may show or hide social icons.', 'bussness' ),
                'default'  => '0',
                'required' => array( 'ht_visibility', '=', true )
            ),
            array(
                'id'         => 'sil_list_facebook',
                'type'       => 'text',
                'title'      => __('Facebook','bussness'),
                'subtitle'   => __('You can add facebook url.','bussness'),
                'desc'       => __('You can add exat url.','bussness'),
                'default'    => esc_url('facebook.com/rubel.ft.me'),
                'required' => array( 'cds_social', '=', 1 )
            ),
            array(
                'id'         => 'sil_list_skype',
                'type'       => 'text',
                'title'      => __('Skype','bussness'),
                'subtitle'   => __('You can add skype url.','bussness'),
                'desc'       => __('You can add exat url.','bussness'),
                'default'    => esc_url('skype.com/rubel.ft.me'),
                'required' => array( 'cds_social', '=', 1 )
            ),
            array(
                'id'         => 'sil_list_twitter',
                'type'       => 'text',
                'title'      => __('Twitter','bussness'),
                'subtitle'   => __('You can add twitter url.','bussness'),
                'desc'       => __('You can add exat url.','bussness'),
                'default'    => esc_url('twitter.com/rubel.ft.me'),
                'required' => array( 'cds_social', '=', 1 )
            ),
            array(
                'id'         => 'sil_list_linkedin',
                'type'       => 'text',
                'title'      => __('Linkedin','bussness'),
                'subtitle'   => __('You can add linkedin url.','bussness'),
                'desc'       => __('You can add exat url.','bussness'),
                'default'    => esc_url('linkedin.com/rubel.ft.me'),
                'required' => array( 'cds_social', '=', 1 )
            ),
            array(
                'id'         => 'sil_list_reedit',
                'type'       => 'text',
                'title'      => __('Reedit','bussness'),
                'subtitle'   => __('You can add reedit url.','bussness'),
                'desc'       => __('You can add exat url.','bussness'),
                'default'    => esc_url('reedit.com/rubel.ft.me'),
                'required' => array( 'cds_social', '=', 1 )
            ),
            array(
                'id'       => 'cds_date',
                'type'     => 'checkbox',
                'title'    => __( 'Date Visibility', 'bussness' ),
                'subtitle' => __( 'You may show or hide top header date.', 'bussness' ),
                'default'  => '0',
                'required' => array( 'ht_visibility', '=', true )
            )
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Header Menu', 'bussness' ),
        'desc'       => __( 'Header menu area visibility options ', 'bussness'),
        'id'         => 'header-menu',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'hm_menu',
                'type'     => 'switch',
                'title'    => __( 'Menu Area Visibility', 'bussness' ),
                'subtitle' => __( 'You may hide or show header menu area.', 'bussness' ),
                'default'  => false
            ),
            array(
                'id'       => 'hm_logo_upload',
                'type'     => 'media',
                'title'    => __( 'Upload Logo', 'bussness' ),
                'subtitle' => __( 'You may upload site\'s logo.', 'bussness' ),
                'default'  => array(
                    'url'  => get_template_directory_uri(). '/lib/img/logo.png'
                ),
                'required' => array( 'hm_menu', '=', true )
            ),
            array(
                'id'       => 'hm_visibility',
                'type'     => 'checkbox',
                'title'    => __( 'Hide Logo Icon', 'bussness' ),
                'subtitle' => __( 'You may hide your logo icon.', 'bussness' ),
                'default'  => '0',
                'required' => array( 'hm_menu', '=', true )
            ),
            array(
                'id'       => 'hm_menu_visibility',
                'type'     => 'checkbox',
                'title'    => __( 'Hide Menu', 'bussness' ),
                'subtitle' => __( 'You may hide your menu icon.', 'bussness' ),
                'default'  => '0',
                'required' => array( 'hm_menu', '=', true )
            ),
            array(
                'id'       => 'hm_position',
                'type'     => 'select',
                'title'    => __( 'Change Logo Position', 'bussness' ),
                'subtitle' => __( 'You may change your logo position.', 'bussness' ),
                'desc'     => __( 'You may change your website\'s logo position.', 'bussness' ),
                'options'  => array(
                    '1'    => 'left',
                    '2'    => 'right'
                ),
                'default'  => '1',
                'required' => array( 'hm_menu', '=', true )
            ),
            array(
                'id'       => 'hm_menu_position',
                'type'     => 'select',
                'title'    => __( 'Change Menu Position', 'bussness' ),
                'subtitle' => __( 'You may change your menu position.', 'bussness' ),
                'desc'     => __( 'You may change your website\'s menu position.', 'bussness' ),
                'options'  => array(
                    'flex-start'  => __('Left menu', 'bussness'),
                    'center'      => __('Center menu', 'bussness'),
                    'flex-end'    => __('End menu', 'bussness')
                ),
                'default'  => 'flex-start',
                'required' => array( 'hm_menu', '=', true )
            ),
            array(
                'id'       => 'hm_menu_drpdown_effect',
                'type'     => 'select',
                'title'    => __( 'Change Dropdown Effect', 'bussness' ),
                'subtitle' => __( 'You may change your dropdown effect.', 'bussness' ),
                'desc'     => __( 'You may change your website\'s dropdown effect .', 'bussness' ),
                'options'  => array(
                    'slide-down'           => 'slide-down',
                    'bounce'               => 'Bounce',
                    'flash'                => 'Flash',
                    'rubberBand'           => 'RubberBand',
                    'shake'                => 'shake',
                    'swing'                => 'swing',
                    'tada'                 => 'tada',
                    'wobble'               => 'wobble',
                    'bounceIn'             => 'bounceIn',
                    'bounceInDown'         => 'bounceInDown',
                    'bounceInLeft'         => 'bounceInLeft',
                    'bounceInRight'        => 'bounceInRight',
                    'bounceInUp'           => 'bounceInUp',
                    'bounceOut'            => 'bounceOut',
                    'bounceOutDown'        => 'bounceOutDown',
                    'bounceOutLeft'        => 'bounceOutLeft',
                    'bounceOutRight'       => 'bounceOutRight',
                    'bounceOutUp'          => 'bounceOutUp',
                    'fadeIn'               => 'fadeIn',
                    'fadeInDown'           => 'fadeInDown',
                    'fadeInDownBig'        => 'fadeInDownBig',
                    'fadeInLeft'           => 'fadeInLeft',
                    'fadeInLeftBig'        => 'fadeInLeftBig',
                    'fadeInRight'          => 'fadeInRight',
                    'fadeInRightBig'       => 'fadeInRightBig',
                    'fadeInUp'             => 'fadeInUp',
                    'fadeInUpBig'          => 'fadeInUpBig',
                    'fadeOut'              => 'fadeOut',
                    'fadeOutDown'          => 'fadeOutDown',
                    'fadeOutDownBig'       => 'fadeOutDownBig',
                    'fadeOutLeft'          => 'fadeOutLeft',
                    'fadeOutLeftBig'       => 'fadeOutLeftBig',
                    'fadeOutRight'         => 'fadeOutRight',
                    'fadeOutRightBig'      => 'fadeOutRightBig',
                    'fadeOutUp'            => 'fadeOutUp',
                    'fadeOutUpBig'         => 'fadeOutUpBig',
                    'flip'                 => 'flip',
                    'flipInX'              => 'flipInX',
                    'flipInY'              => 'flipInY',
                    'flipOutX'             => 'flipOutX',
                    'flipOutY'             => 'flipOutY',
                    'lightSpeedIn'         => 'lightSpeedIn',
                    'lightSpeedOut'        => 'lightSpeedOut',
                    'rotateIn'             => 'rotateIn',
                    'rotateInDownLeft'     => 'rotateInDownLeft',
                    'rotateInDownRight'    => 'rotateInDownRight',
                    'rotateInUpLeft'       => 'rotateInUpLeft',
                    'rotateInUpRight'      => 'rotateInUpRight',
                    'rotateOut'            => 'rotateOut',
                    'rotateOutDownLeft'    => 'rotateOutDownLeft',
                    'rotateOutDownRight'   => 'rotateOutDownRight',
                    'rotateOutUpLeft'      => 'rotateOutUpLeft',
                    'rotateOutUpRight'     => 'rotateOutUpRight',
                    'slideInDown'          => 'slideInDown',
                    'slideInLeft'          => 'slideInLeft',
                    'slideInRight'         => 'slideInRight',
                    'slideOutLeft'         => 'slideOutLeft',
                    'slideOutRight'        => 'slideOutRight',
                    'slideOutUp'           => 'slideOutUp',
                    'slideInUp'            => 'slideInUp',
                    'slideOutDown'         => 'slideOutDown',
                    'hinge'                => 'hinge',
                    'rollIn'               => 'rollIn',
                    'rollOut'              => 'rollOut',
                    'zoomIn'               => 'zoomIn',
                    'zoomInDown'           => 'zoomInDown',
                    'zoomInLeft'           => 'zoomInLeft',
                    'zoomInRight'          => 'zoomInRight',
                    'zoomInUp'             => 'zoomInUp',
                    'zoomOut'              => 'zoomOut',
                    'zoomOutDown'          => 'zoomOutDown',
                    'zoomOutLeft'          => 'zoomOutLeft',
                    'zoomOutRight'         => 'zoomOutRight',
                    'zoomOutUp'            => 'zoomOutUp'
                ),
                'default'  => 'slide-down',
                'required' => array( 'hm_menu', '=', true )
            ),
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __('Breadcrumbs', 'bussness'),
        'desc'       => __('Breadcrumbs Options', 'bussness'),
        'id'         => 'bread-crumb',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'        => 'bo_breadcrumb',
                'type'      => 'checkbox',
                'title'     => __('Breadcrumbs Visibility', 'bussness'),
                'subtitle'  => __('You can show or hide this breadcrumbs.', 'bussness'),
                'desc'      => __('You may change the visibility options', 'bussness'),
                'options'   => array('Checked it and show breadcrumbs'),
                'default'   => '0'
            ),
            array(
                'id'        => 'bo_breadcrumb_clr',
                'type'      => 'color',
                'title'     => __('Breadcrumbs Background Color', 'bussness'),
                'subtitle'  => __('You can change breadcrumbs background color.', 'bussness'),
                'desc'      => __('You may change breadcrumbs background color', 'bussness'),
                'default'   => '#6C757D'
            )
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __('Ticker', 'bussness'),
        'desc'       => __('Tickers Options', 'bussness'),
        'id'         => 'ticker-option',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'        => 'ticker',
                'type'      => 'checkbox',
                'title'     => __('Ticker Visibility', 'bussness'),
                'subtitle'  => __('You can show or hide this ticker.', 'bussness'),
                'desc'      => __('You may change the visibility options', 'bussness'),
                'options'   => array('Checked it and show ticker'),
                'default'   => '0'
            ),
            array(
                'id'        => 'ticker_text',
                'type'      => 'textarea',
                'title'     => __('Ticker Text', 'bussness'),
                'subtitle'  => __('You can white something.', 'bussness'),
                'desc'      => __('You may write something and show into website', 'bussness'),
                'default'   => ''
            )
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Slider', 'bussness' ),
        'desc'       => __( 'Slider Options', 'bussness'),
        'id'         => 'slider-options',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'so_slider',
                'type'     => 'select',
                'title'    => __( 'Slides limit', 'bussness' ),
                'subtitle' => __( 'You may change slides number', 'bussness' ),
                'options'  => array(
                    '3'    => __('Minimum', 'bussness'),
                    '5'    => __('Normal', 'bussness'),
                    '7'    => __('Maximum', 'bussness'),
                ),
                'default'  => '5'
            ),
            array(
                'id'       => 'so_visibility',
                'type'     => 'checkbox',
                'title'    => __( 'Slides Visibility', 'bussness' ),
                'subtitle' => __( 'You may shoe or hide slider section', 'bussness' ),
                'default'  => '0'
            )
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Preloader', 'bussness' ),
        'id'         => 'preloader',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'preloader_visibility',
                'type'     => 'checkbox',
                'title'    => __('Preloader Visibility', 'bussness'),
                'subtitle' => __('You can show or hide preloader effects.', 'bussness'),
                'desc'     => __('You may show or hide preloader effects.', 'bussness'),
                'options'  => array( '1' => __('Preloader visibility','bussness') ),
                'default'  => '1'  
            ),
            array(
                'id'       => 'preloader_change_effect',
                'type'     => 'select',
                'title'    => __('Change Preloader Effects', 'bussness'),
                'subtitle' => __('You can the preloader effects.', 'bussness'),
                'desc'     => __('You may the preloader effects.', 'bussness'),
                'options'  => array(
                    '1'    => 'Wave',
                    '2'    => 'Ajax Loader',
                    '3'    => 'Ajax Door',
                    '4'    => 'Ajax Grow',
                    '5'    => 'Ajax Loading',
                    '6'    => 'Ajax load',
                    '7'    => 'Ajax Hack',
                ),
                'default'  => '1'
            ),

            array(
                'id'       => 'preloader_color_id',
                'type'     => 'color',
                'title'    => __('Preloader Color', 'bussness'),
                'subtitle' => __('You can show or hide preloader effects.', 'bussness'),
                'desc'     => __('You may show or hide preloader effects.', 'bussness'),
                'default'  => '#66BC7B'  
            )
        )
    ) );
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Latest Post', 'bussness' ),
        'desc'       => __( 'latest post', 'bussness'),
        'id'         => 'latest_post',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'lp_post',
                'type'     => 'checkbox',
                'title'    => __('Latest Post Visibility', 'bussness'),
                'subtitle' => __('You can change visibility.', 'bussness'),
                'desc'     => __('You may change the latest post visibility from here', 'bussness'),
                'options'  => array('Checked the checkbox and than show the latest post'),
                'default'  => '0'
            )
        )
    ) );


    Redux::setSection( $opt_name, array(
        'title'      => __( 'Feature Post', 'bussness' ),
        'id'         => 'feature-posts',
        'desc'       => __( 'You can change feature post area\'s design from here.', 'bussness'),
        // 'subsection' => true,
        'icon'       => 'el el-network',
        'fields'     => array(
            array(
                'id'       => 'fp_all_visibility',
                'type'     => 'checkbox',
                'title'    => __('Visibility', 'bussness'),
                'subtitle' => __('You can show or hide feature post area.', 'bussness'),
                'desc'     => __('You may show or hide feature post area.', 'bussness'),
                'options'  => array(__('Feature post visibility','bussness')),
                'default'  => '0'     
            ),
            array(
                'id'       => 'fp_all_title_visibility',
                'type'     => 'switch',
                'title'    => __('Title Visibility', 'bussness'),
                'subtitle' => __('You can show or hide feature post title area.', 'bussness'),
                'desc'     => __('You may show or hide feature post title area.', 'bussness'),
                'default'  => false    
            ),
            array(
                'id'       => 'fp_all_title_text',
                'type'     => 'text',
                'title'    => __('Title', 'bussness'),
                'subtitle' => __('You can change the title.', 'bussness'),
                'desc'     => __('You may change the title from here.', 'bussness'),
                'default'  => __('Feature Post', 'bussness'),
                'required' => array('fp_all_title_visibility', '=', true)    
            ),
            array(
                'id'       => 'fp_all_title_color',
                'type'     => 'color',
                'title'    => __('Color', 'bussness'),
                'subtitle' => __('You can change the title color.', 'bussness'),
                'desc'     => __('You may change the title color from here.', 'bussness'),
                'default'  => '#462529',
                'required' => array('fp_all_title_visibility', '=', true)    
            ),
            array(
                'id'       => 'fp_all_title_bg_color',
                'type'     => 'color',
                'title'    => __('Background Color', 'bussness'),
                'subtitle' => __('You can change the title background.', 'bussness'),
                'desc'     => __('You may change the title background from here.', 'bussness'),
                'default'  => '#ffffff',
                'required' => array('fp_all_title_visibility', '=', true)    
            ),
            array(
                'id'       => 'fp_all_title_position',
                'type'     => 'select',
                'title'    => __('Title Position', 'bussness'),
                'subtitle' => __('You can change the title position.', 'bussness'),
                'desc'     => __('You may change the title position from here.', 'bussness'),
                'options'  => array(
                    'left'   => __('Left', 'bussness'),
                    'center' => __('Center', 'bussness'),
                    'right'  => __('Right', 'bussness'),
                ),
                'default'  => 'left',
                'required' => array('fp_all_title_visibility', '=', true)    
            ),
            array(
                'id'       => 'fp_all_visibility_button',
                'type'     => 'button_set',
                'title'    => __('Visibility', 'bussness'),
                'subtitle' => __('You can show or hide feature post\'s specefic area.', 'bussness'),
                'desc'     => __('You may show or hide feature post\'s specefic area.', 'bussness'),
                'options'  => array(
                    '1'    => __('Left Swipe', 'bussness'),
                    '2'    => __('box Swipe', 'bussness'),
                    '3'    => __('Right Swipe', 'bussness'),
                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'fp_all_visibility_left',
                'type'     => 'checkbox',
                'title'    => __('Left Swipe Visibility', 'bussness'),
                'subtitle' => __('You can show or hide feature post left swipe area.', 'bussness'),
                'desc'     => __('You may show or hide feature post left swipe area.', 'bussness'),
                'options'  => array(__('Left swipe up visibility', 'bussness')),
                'default'  => '0',
                'required' => array('fp_all_visibility_button', '=', 1)
            ),
            array(
                'id'       => 'fp_all_visibility_middle',
                'type'     => 'checkbox',
                'title'    => __('Middle Swipe Visibility', 'bussness'),
                'subtitle' => __('You can show or hide feature post middle swipe area.', 'bussness'),
                'desc'     => __('You may show or hide feature post middle swipe area.', 'bussness'),
                'options'  => array(__('Middle swipe up visibility', 'bussness')),
                'default'  => '0',
                'required' => array('fp_all_visibility_button', '=', 2)
            ),
            array(
                'id'       => 'fp_all_visibility_right',
                'type'     => 'checkbox',
                'title'    => __('Right Swipe Visibility', 'bussness'),
                'subtitle' => __('You can show or hide feature post right swipe area.', 'bussness'),
                'desc'     => __('You may show or hide feature post right swipe area.', 'bussness'),
                'options'  => array(__('Right swipe up visibility', 'bussness')),
                'default'  => '0',
                'required' => array('fp_all_visibility_button', '=', 3)
            ),
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title' => __( 'Missed Post', 'bussness' ),
        'id'    => 'missed-post',
        'desc'  => __( 'You have missed post title.', 'bussness' ),
        'icon'  => 'el el-barcode',
        'fields'=> array(
            array(
                'id'       => 'mp_check',
                'type'     => 'radio',
                'title'    => __('Title Visibility', 'bussness'),
                'subtitle' => __('You can change the title visibility.', 'bussness'),
                'desc'     => __('You may change the title visibility from here', 'bussness'),
                'options'  => array(
                    'block'  => 'Show',
                    'none'   => 'Hide'
                ),
                'default'  => 'none'
            ),
            array(
                'id'       => 'mp_post',
                'type'     => 'text',
                'title'    => __('Missed Post Title', 'bussness'),
                'subtitle' => __('Write  the missed post title from here.', 'bussness'),
                'default'  => __('May You Have Missed This Post!', 'bussness') ,
                'required' => array('mp_check', '=', 'block')
            ),
        )
    ) );

    redux::setSection( $opt_name, array(
        'title'      => __( 'Sidebars', 'bussness' ),
        'id'         => 'sidebar-area',
        'desc'       => __( 'You can change sidebar area\'s design from here.', 'bussness'),
        'icon'      => 'el el-network',
        'fields'      => array(
            array(
                'id'       => 'sidebars_all',
                'type'     => 'checkbox',
                'title'    => __('Show All Sidebars', 'bussness'),
                'subtitle' => __('You can show or hide any sidebar.', 'bussness'),
                'desc'     => __('You may show or hide any sidebar from here.', 'bussness'),
                'default'  => '0'                
            ),
            array(
                'id'       => 'sa_left_sidebar',
                'type'     => 'radio',
                'title'    => __('Left Sidebar', 'bussness'),
                'subtitle' => __('You can show or hide this sidebar.', 'bussness'),
                'desc'     => __('You may show or hide this sidebar from here.', 'bussness'),
                'options'  => array(
                    'block'=> 'Visible',
                    'none' => 'Unisible',
                ),
                'default'  => 'none',
                'required' => array('sidebars_all', '=', 1)        
            ),
            array(
                'id'       => 'sa_right_sidebar',
                'type'     => 'radio',
                'title'    => __('Right Sidebar', 'bussness'),
                'subtitle' => __('You can show or hide this sidebar.', 'bussness'),
                'desc'     => __('You may show or hide this sidebar from here.', 'bussness'),
                'options'  => array(
                    'block'=> 'Visible',
                    'none' => 'Unisible',
                ),
                'default'  => 'none',
                'required' => array('sidebars_all', '=', 1)     
            ),
        )
    ) );


    Redux::setSection( $opt_name, array(
        'title' => __( 'Static Section', 'bussness' ),
        'id'    => 'static',
        'desc'  => __( 'You can add your self.', 'bussness' ),
        'icon'  => 'el el-user',
        'fields'=> array(
            array(
                'id'       => 'st_check',
                'type'     => 'checkbox',
                'title'    => __( 'Visibility', 'bussness' ),
                'subtitle' => __( 'You may change visibility', 'bussness' ),
                'options'  => array('checked this you can see the section'),
                'default'  => '0'
            ),
            array(
                'id'       => 'st_thumb',
                'type'     => 'media',
                'title'    => __( 'Add Image', 'bussness' ),
                'subtitle' => __( 'You may add image', 'bussness' ),
                'default'  => array(
                    'url'  => get_template_directory_uri().'/lib/img/image.jpg'
                )
            ),
            array(
                'id'       => 'st_title',
                'type'     => 'text',
                'title'    => __( 'Post Title', 'bussness' ),
                'subtitle' => __( 'You may add title', 'bussness' ),
                'default'  => 'Static Post Title'
            ),
            array(
                'id'       => 'st_description',
                'type'     => 'textarea',
                'title'    => __( 'Post Description', 'bussness' ),
                'subtitle' => __( 'You may add description', 'bussness' ),
                'default'  => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde pariatur cupiditate enim porro incidunt! Molestias harum alias delectus, architecto. In laboriosam temporibus harum a, voluptas magnam? Quis tempore incidunt culpa quaerat amet fugit repudiandae praesentium illo alias reiciendis! In quae, voluptas neque blanditiis tenetur sint aperiam veniam ducimus quos accusamus magni delectus nostrum, omnis esse quam ad odit deserunt? Est impedit perferendis, recusandae quaerat fuga sunt? Maxime earum eligendi id provident, nam deleniti libero ut inventore, cumque nemo. Quod consequatur maxime quam. Molestias, similique quo, amet expedita fuga, earum reiciendis id quidem repellendus assumenda aspernatur qui adipisci asperiores magni laborum. Aliquid autem quam ipsa illum est corrupti magni eligendi rerum dolorum voluptatum impedit optio ipsum perferendis, similique ducimus dolores, maxime nostrum accusantium deleniti molestiae consequatur odio nisi. Minima laudantium pariatur fugit qui, modi similique tempore enim! Architecto quae qui natus expedita, sint iste illum. Fuga libero commodi, et facilis corrupti.'
            )
        )
    ) );
    // title section
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Section Area', 'bussness' ),
        'id'         => 'all-title-area',
        'desc'       => __( 'All section title are here, you may change the title text and title color from here.', 'bussness'),
        'icon'       => 'el el-text-height',
        'fields'     => array(
            array(
                'id'       => 'all-title-areas',
                'type'     => 'switch',
                'title'    => __('Title Area', 'bussness'),
                'subtitle' => __('All title area\'s text and color change from here.', 'bussness'),
                'default'  => false
            ),
            array(
                'id'       => 'all-title-button',
                'type'     => 'button_set',
                'title'    => __('Title Area', 'bussness'),
                'subtitle' => __('All title area\'s text and color change from here.', 'bussness'),
                'required' => array('all-title-areas', '=', true),
                'options'  => array(
                    '1'    => __('Service Area', 'bussness'),
                    '2'    => __('About Area', 'bussness')
                ),
                'default'  => 1
            ),
            array(
                'id'       => 'atb_srv_section_visibility',
                'type'     => 'checkbox',
                'title'    => __('Visibility', 'bussness'),
                'subtitle' => __('You can show or hide this section', 'bussness'),
                'required' => array('all-title-button', '=', 1),
                'options'  => array('Checked the checkbox than show the section'),
                'default'  => '0'
            ),
            array(
                'id'       => 'atb_srv_title_visible',
                'type'     => 'checkbox',
                'title'    => __('Visibility (title)', 'bussness'),
                'subtitle' => __('You can show or hide this section', 'bussness'),
                'required' => array('all-title-button', '=', 1),
                'default'  => '0'
            ),
            array(
                'id'       => 'atb_srv_title',
                'type'     => 'text',
                'title'    => __('Title', 'bussness'),
                'subtitle' => __('Change the title from here.', 'bussness'),
                'desc'     => __('You may change the title text', 'bussness'),
                'required' => array('atb_srv_title_visible', '=', 1),
                'default'  => __('Title name', 'bussness')
            ),
            array(
                'id'       => 'atb_srv_title_clr',
                'type'     => 'color',
                'title'    => __('Color', 'bussness'),
                'subtitle' => __('Change the title\'s color from here.', 'bussness'),
                'desc'     => __('You may change the title color'),
                'required' => array('atb_srv_title_visible', '=', 1),
                'default'  => '#272529'
            ),
            array(
                'id'       => 'atb_srv_description_visible',
                'type'     => 'checkbox',
                'title'    => __('Visibility (description)', 'bussness'),
                'subtitle' => __('You can show or hide this section', 'bussness'),
                'required' => array('all-title-button', '=', 1),
                'default'  => '0'
            ),
            array(
                'id'       => 'atb_srv_description',
                'type'     => 'textarea', 
                'title'    => __('Description', 'bussness'),
                'subtitle' => __('Change the desction from here.', 'bussness'),
                'desc'     => __('You may change the description text'),
                'required' => array('atb_srv_description_visible', '=', 1),
                'default'  => __('lorem ipsum dolar lorem ipsum dolar', 'bussness')
            ),
            array(
                'id'       => 'atb_srv_description_clr',
                'type'     => 'color', 
                'title'    => __('Color', 'bussness'),
                'subtitle' => __('Change the desctions color from here.', 'bussness'),
                'desc'     => __('You may change the description color'),
                'required' => array('atb_srv_description_visible', '=', 1),
                'default'  => '#272529'
            ),
            array(
                'id'       => 'atb_abt_section_visibility',
                'type'     => 'checkbox',
                'title'    => __('Visibility', 'bussness'),
                'subtitle' => __('You can show or hide this section', 'bussness'),
                'required' => array('all-title-button', '=', 2),
                'options'  => array('Checked the checkbox than show the section'),
                'default'  => '0'
            ),
            array(
                'id'       => 'atb_abt_title_visible',
                'type'     => 'checkbox',
                'title'    => __('Visibility (title)', 'bussness'),
                'subtitle' => __('You can show or hide this section', 'bussness'),
                'required' => array('all-title-button', '=', 2),
                'default'  => '0'
            ),
            array(
                'id'       => 'atb_abt_title',
                'type'     => 'text',
                'title'    => __('Title', 'bussness'),
                'subtitle' => __('Change the title from here.', 'bussness'),
                'desc'     => __('You may change the title text'),
                'required' => array('atb_abt_title_visible', '=', 1),
                'default'  => __('Title name', 'bussness')
            ),
            array(
                'id'       => 'atb_abt_title_clr',
                'type'     => 'color',
                'title'    => __('Color', 'bussness'),
                'subtitle' => __('Change the title\'s color from here.', 'bussness'),
                'desc'     => __('You may change the title color'),
                'required' => array('atb_abt_title_visible', '=', 1),
                'default'  => '#272529'
            ),
            array(
                'id'       => 'atb_abt_description_visible',
                'type'     => 'checkbox',
                'title'    => __('Visibility (description)', 'bussness'),
                'subtitle' => __('You can show or hide this section', 'bussness'),
                'required' => array('all-title-button', '=', 2),
                'default'  => '0'
            ),
            array(
                'id'       => 'atb_abt_description',
                'type'     => 'textarea', 
                'title'    => __('Description', 'bussness'),
                'subtitle' => __('Change the desction from here.', 'bussness'),
                'desc'     => __('You may change the description text'),
                'required' => array('atb_abt_description_visible', '=', 1),
                'default'  => __('lorem ipsum dolar lorem ipsum dolar', 'bussness')
            ),
            array(
                'id'       => 'atb_abt_description_clr',
                'type'     => 'color', 
                'title'    => __('Color', 'bussness'),
                'subtitle' => __('Change the desctions color from here.', 'bussness'),
                'desc'     => __('You may change the description color'),
                'required' => array('atb_abt_description_visible', '=', 1),
                'default'  => '#272529'
            )
        )
    ) ); // end title section

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer Area', 'bussness' ),
        'id'         => 'footer-area-all',
        'desc'       => __( 'All footer area here, you may change some design from here.', 'bussness'),
        'icon'       => 'el el-heart-alt'
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer Top Area.', 'bussness' ),
        'id'         => 'footer-area-top',
        'subsection' => true,
        'desc'       => __( 'All usefull details here, you can change some design from here.', 'bussness'),
        'fields'     => array(
            array(
                'id'       => 'footer-top-area-visibility',
                'type'     => 'checkbox',
                'title'    => __('Footer Top Area.', 'bussness'),
                'subtitle' => __('Footer Top Area Visiblility', 'bussness'),
                'desc'     => __('You may change the visibility', 'bussness'),
                'options'  => array('This section visibility'),
                'default'  => '0'
            ),
            array(
                'id'       => 'fat_visibility',
                'type'     => 'button_set',
                'title'    => __('Footer Area', 'bussness'),
                'subtitle' => __('Footer Area Visiblility', 'bussness'),
                'options'  => array(
                    '1'    => __('Our Headquarters', 'bussness'),
                    '2'    => __('Contact Form', 'bussness'),
                    '3'    => __('Subscribe US', 'bussness')
                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'headquarters-title',
                'type'     => 'text',
                'title'    => __('Title', 'bussness'),
                'subtitle' => __('This is the list title', 'bussness'),
                'desc'     => __('You may change the title.', 'bussness'),
                'required' => array('fat_visibility', '=', 1),
                'default'  => __('Our Headquarters', 'bussness')
            ),
            array(
                'id'       => 'headquarters-phone',
                'type'     => 'text',
                'title'    => __('Phone Number', 'bussness'),
                'subtitle' => __('You can phone number from here.', 'bussness'),
                'required' => array('fat_visibility', '=', 1),
                'default'  => '+880171-4240934'
            ),
            array(
                'id'       => 'headquarters-email',
                'type'     => 'text',
                'title'    => __('Email Address', 'bussness'),
                'required' => array('fat_visibility', '=', 1),
                'default'  => 'vxlrubel@gmail.com'
            ),
            array(
                'id'       => 'headquarters-address',
                'type'     => 'textarea',
                'title'    => __('Address', 'bussness'),
                'subtitle' => __('You can change the address from here.', 'bussness'),
                'desc'     => __('You may change the Address.', 'bussness'),
                'required' => array('fat_visibility', '=', 1),
                'default'  => '925 Avenue of Gulshan-2 in Dhaka-1212'
            ),

            array(
                'id'       => 'headquarters-visibility',
                'type'     => 'checkbox',
                'title'    => __('Headquarters Visibility', 'bussness'),
                'subtitle' => __('Hide or show.', 'bussness'),
                'required' => array('fat_visibility', '=', 1),
                'options'  => array('Checked it and visible this area.'),
                'default'  => '0'
            ),
            array(
                'id'       => 'contact-us-footer',
                'type'     => 'text',
                'title'    => __('Title', 'bussness'),
                'subtitle' => __('This is the contact title', 'bussness'),
                'desc'     => __('You may change the title.', 'bussness'),
                'required' => array('fat_visibility', '=', 2),
                'default'  => 'Contact Us'
            ),
            array(
                'id'       => 'contact-visibility',
                'type'     => 'checkbox',
                'title'    => __('Contact Visibility', 'bussness'),
                'subtitle' => __('Hide or show.', 'bussness'),
                'required' => array('fat_visibility', '=', 2),
                'options'  => array('Checked it and visible this area.'),
                'default'  => '0'
            ),
            array(
                'id'       => 'subscribe-us-title',
                'type'     => 'text',
                'title'    => __('Title', 'bussness'),
                'subtitle' => __('Subscribe title change from here.', 'bussness'),
                'desc'     => __('You may change the title.', 'bussness'),
                'required' => array('fat_visibility', '=', 3),
                'default'  => 'Subscribe Us'
            ),
            array(
                'id'       => 'subscribe-us-label',
                'type'     => 'text',
                'title'    => __('Button Label', 'bussness'),
                'subtitle' => __('You can change the button label from here.', 'bussness'),
                'desc'     => __('You may change button label.', 'bussness'),
                'required' => array('fat_visibility', '=', 3),
                'default'  => 'Subscribe'
            ),
            array(
                'id'       => 'subscribe-visibility',
                'type'     => 'checkbox',
                'title'    => __('Subscribe Visibility', 'bussness'),
                'subtitle' => __('Hide or show.', 'bussness'),
                'required' => array('fat_visibility', '=', 3),
                'options'  => array('Checked it and visible this area.'),
                'default'  => '0'
            )
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __('Scroll To Top', 'bussness'),
        'subtitle'   => __('Scroll to top area.', 'bussness'),
        'subsection' => true,
        'desc'       => __('You can change scroll to top button design.', 'bussness'),
        'id'         => 'scroll-to-top',
        'fields'     => array(
            array(
                'id'        => 'scroll_top',
                'type'      => 'checkbox',
                'title'     => __('Scroll to top visibility', 'bussness'),
                'subtitle'  => __('You can change visibility.', 'bussness'),
                'desc'      => __('You may change visibility.', 'bussness'),
                'options'   => array('Checked the checkbox and than show the visibility.'),
                'default'   => '0'
            ),
            array(
                'id'        => 'scroll_top_position',
                'type'      => 'select',
                'title'     => __('Position', 'bussness'),
                'subtitle'  => __('You can change Position.', 'bussness'),
                'desc'      => __('You may change Position.', 'bussness'),
                'options'   => array(
                    '1'     => __('Top Left','bussness'),
                    '2'     => __('Top Center','bussness'),
                    '3'     => __('Top Right','bussness'),
                    '4'     => __('Bottom Left','bussness'),
                    '5'     => __('Bottom Center','bussness'),
                    '6'     => __('Bottom Right','bussness'),
                ),
                'default'   => '6'
            ),
            array(
                'id'        => 'scroll_top_icon',
                'type'      => 'select',
                'title'     => __('Scroll to top icon select', 'bussness'),
                'subtitle'  => __('You can change icon select.', 'bussness'),
                'desc'      => __('You may change icon select.', 'bussness'),
                'options'   => array(
                    '1'     => __( 'Arrow Circle', 'bussness' ),
                    '2'     => __( 'Arrow Circle Alt', 'bussness' ),
                    '3'     => __( 'Caret Square', 'bussness' ),
                    '4'     => __( 'Angle Dubble', 'bussness' ),
                    '5'     => __( 'Angle', 'bussness' ),
                    '6'     => __( 'Circle Up', 'bussness' ),
                    '7'     => __( 'Long', 'bussness' ),
                    '8'     => __( 'Arrow Up', 'bussness' ),
                    '9'     => __( 'Square', 'bussness' ),
                    '10'    => __( 'Caret', 'bussness' ),
                    '11'    => __( 'Chevron Circle', 'bussness' ),
                    '12'    => __( 'Chevron', 'bussness' ),
                    '13'    => __( 'level', 'bussness' ),
                ),
                'default'   => '1'
            ),
            array(
                'id'        => 'scroll_top_clr_setup',
                'type'      => 'switch',
                'title'     => __('Scroll to top Color and Background', 'bussness'),
                'subtitle'  => __('You can change Color and Background.', 'bussness'),
                'desc'      => __('You may change Color and Background.', 'bussness'),
                'default'   => false
            ),
            array(
                'id'        => 'scroll_top_color',
                'type'      => 'color',
                'title'     => __('Color', 'bussness'),
                'subtitle'  => __('You can change Color.', 'bussness'),
                'desc'      => __('You may change Color.', 'bussness'),
                'default'   => '#fff',
                'required'  => array( 'scroll_top_clr_setup', '=', true )
            ),
            array(
                'id'        => 'scroll_top_color_hover',
                'type'      => 'color',
                'title'     => __('Hover Color', 'bussness'),
                'subtitle'  => __('You can change Hover Color.', 'bussness'),
                'desc'      => __('You may change Hover Color.', 'bussness'),
                'default'   => '#66BC7B',
                'required'  => array( 'scroll_top_clr_setup', '=', true )
            ),
            array(
                'id'        => 'scroll_top_bg',
                'type'      => 'color',
                'title'     => __('Background Color', 'bussness'),
                'subtitle'  => __('You can change Background Color.', 'bussness'),
                'desc'      => __('You may change Background Color.', 'bussness'),
                'default'   => '#343a40',
                'required'  => array( 'scroll_top_clr_setup', '=', true )
            ),
            array(
                'id'        => 'scroll_top_bg_hover',
                'type'      => 'color',
                'title'     => __('Hover Background Color', 'bussness'),
                'subtitle'  => __('You can change Background Color.', 'bussness'),
                'desc'      => __('You may change Background Color.', 'bussness'),
                'default'   => '#fff',
                'required'  => array( 'scroll_top_clr_setup', '=', true )
            ),
            array(
                'id'        => 'scroll_top_border_color',
                'type'      => 'color',
                'title'     => __('Border Color', 'bussness'),
                'subtitle'  => __('You can change Border Color.', 'bussness'),
                'desc'      => __('You may change Border Color.', 'bussness'),
                'default'   => 'transparent',
                'required'  => array( 'scroll_top_clr_setup', '=', true )
            ),
            array(
                'id'        => 'scroll_top_border_hover_color',
                'type'      => 'color',
                'title'     => __('Hover Border Hover Color', 'bussness'),
                'subtitle'  => __('You can change Border Hover Color.', 'bussness'),
                'desc'      => __('You may change Border Hover Color.', 'bussness'),
                'default'   => '#66BC7B',
                'required'  => array( 'scroll_top_clr_setup', '=', true )
            ),
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Copyright Area', 'bussness' ),
        'id'         => 'footer-area',
        'subsection' => true,
        'desc'       => __( 'You can change copyright area\'s design from here.', 'bussness'),
        'fields'      => array(
            array(
                'id'       => 'fa_visibility',
                'type'     => 'switch',
                'title'    => __('Footer Area', 'bussness'),
                'subtitle' => __('Footer Area Visiblility', 'bussness'),
                'default'  => false
            ),
            array(
                'id'       => 'fa_copyright_text',
                'type'     => 'text',
                'title'    => __('Copyright text', 'bussness'),
                'desc'     => __('You may change the copyright text', 'bussness'),
                'subtitle' => __('Change the copyright text', 'bussness'),
                'default'  => __('Copyright© 2020 Allright Reserved By Mrm Sujan. ', 'bussness'),
                'required' => array( 'fa_visibility', '=', true )
            ),
            array(
                'id'       => 'fa_copyright_color',
                'type'     => 'color',
                'title'    => __('Copyright color', 'bussness'),
                'desc'     => __('You may change the copyright color', 'bussness'),
                'subtitle' => __('Change the copyright color', 'bussness'),
                'default'  => '#66BC7B',
                'required' => array( 'fa_visibility', '=', true )
            ),
            array(
                'id'       => 'fa_copyright_position',
                'type'     => 'select',
                'title'    => __('Copyright color', 'bussness'),
                'desc'     => __('You may change the copyright color', 'bussness'),
                'subtitle' => __('Change the copyright color', 'bussness'),
                'required' => array( 'fa_visibility', '=', true ),
                'options'  => array(
                    'left'   => __('Left', 'bussness'),
                    'center' => __('Center', 'bussness'),
                    'right'  => __('Right', 'bussness')
                ),
                'default'  => 'center',
            ),
            array(
                'id'       => 'fa_copyright_text_visibility',
                'type'     => 'checkbox',
                'title'    => __('Copyright text visibility', 'bussness'),
                'desc'     => __('You may change the copyright visibility', 'bussness'),
                'subtitle' => __('Change the copyright visibility', 'bussness'),
                'required' => array( 'fa_visibility', '=', true ),
                'default'  => '0',
            ),
            array(
                'id'       => 'test-widget',
                'type'     => 'text',
                'title'    => __('Test Title', 'bussness'),
                'default'  => 'bello',
            ),
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Image Slider', 'bussness' ),
        'id'         => 'additional-slides',
        'desc'       => __( 'For full documentation on this field, visit: ', 'bussness' ) . '<a href="#" target="_blank">documentation</a>',
        'fields'     => array(
            array(
                'id'          => 'opt-slides',
                'type'        => 'slides',
                'title'       => __( '<h2 class="new">Add New Slider </h2>', 'bussness' ),
                'subtitle'    => __( 'You can add new slider from here.', 'bussness' ),
                'desc'        => __( 'This field will store all slides values into a multidimensional array to use into a foreach loop.', 'bussness' ),
                'placeholder' => array(
                    'title'       => __( 'This is a title', 'bussness' ),
                    'description' => __( 'Description Here', 'bussness' ),
                    'url'         => __( 'Give us a link!', 'bussness' ),
                ),
            ),
        )
    ) );