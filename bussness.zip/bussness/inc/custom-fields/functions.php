<?php 

if (file_exists(dirname(__FILE__).'/cmb2/init.php')) {
	require_once dirname(__FILE__).'/cmb2/init.php';
}

function bussness_about_custom_fields(){

	$prefix = '_bussness_';
	$bussness_about = new_cmb2_box(array(
		'title'		   => __( 'Add New Person', 'bussness' ),
		'object_types' => array( 'about' ),
		'id' 			   => $prefix.'about',
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true,
		'fields' => array(
			array(
			'name' => __( 'Name :', 'bussness' ),
			'desc' => __( 'Write your name here', 'bussness' ),
			'id'   => $prefix.'name',
			'type' => 'text',
			),
			array(
			'name' => __( 'Designation :', 'bussness' ),
			'desc' => __( 'Write your designation here', 'bussness' ),
			'id'   => $prefix.'designation',
			'type' => 'text',
			),
			array(
			'name' => __( 'Image :', 'bussness' ),
			'desc' => __( 'upload your image', 'bussness' ),
			'id'   => $prefix.'image',
			'type' => 'file',
			),
			array(
			'name' => __( 'Information\'s button label :', 'bussness' ),
			'desc' => __( 'Enter button label', 'bussness' ),
			'id'   => $prefix.'info_button_label',
			'type' => 'text_medium',
			),
			array(
			'name' => __( 'Incormations Conector Id:', 'bussness' ),
			'desc' => __( 'You must be add connector id like single word.', 'bussness' ),
			'id'   => $prefix.'info_connector',
			'type' => 'text_medium',
			),
			array(
			'name' => __( 'Information\'s:', 'bussness' ),
			'desc' => __( 'Enter member\'s Information.', 'bussness' ),
			'id'   => $prefix.'info',
			'type' => 'textarea_small',
			),
			array(
			'name' => __( 'Contact button label:', 'bussness' ),
			'desc' => __( 'You may add button label.', 'bussness' ),
			'id'   => $prefix.'info_button',
			'type' => 'text_medium',
			),
			array(
			'name' => __( 'Form Conector Id:', 'bussness' ),
			'desc' => __( 'You must be add connector id like single word.', 'bussness' ),
			'id'   => $prefix.'info_form',
			'type' => 'text_medium',
			)
		)
	) );


}
add_action('cmb2_admin_init', 'bussness_about_custom_fields');

function bussness_all_post_types_field(){
	$prefix = '_bussness_';
	$bussness_all_post_types = new_cmb2_box(array(
		'title'		   => __( 'Title', 'bussness' ),
		'object_types' => array( 'post', 'page', 'about', 'services' ),
		'id' 			   => $prefix.'all_post_types',
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true,
		'fields'       => array(
			array(
				'name'    => __('Color','bussness'),
				'type'    => 'colorpicker',
				'id'      => $prefix.'light',
				'default' => '#222'
			)
		)
	));


}
add_action('cmb2_admin_init', 'bussness_all_post_types_field');