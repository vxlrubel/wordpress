<?php 
/**
 * @package Register Post Type
 */
/**
 * @see Services
 */
add_action( 'init', 'bussness_register_post_service' );

if( ! function_exists( 'bussness_register_post_service' ) ) :

	// create post type services
	function bussness_register_post_service(){
		$labels = [
			'name'               => __( 'Services', 'bussness'),
			'singular_name'      => __( 'Service', 'bussness'),
			'menu_name'          => __( 'Services', 'bussness'),
			'name_admin_bar'     => __( 'Add Service', 'bussness'),
			'add_new'            => __( 'Add New', 'bussness'),
			'add_new_item'       => __( 'Add New Service', 'bussness' ),
			'new_item'           => __( 'New Service', 'bussness' ),
			'edit_item'          => __( 'Edit Service', 'bussness' ),
			'view_item'          => __( 'View Service', 'bussness' ),
			'all_items'          => __( 'All Services', 'bussness' ),
			'search_items'       => __( 'Search Services', 'bussness' ),
			'parent_item_colon'  => __( 'Parent Service:', 'bussness' ),
			'not_found'          => __( 'No Service found.', 'bussness' ),
			'not_found_in_trash' => __( 'No Service found in Trash.', 'bussness' )
		];

		$args = [
			'labels'             => $labels,
	    'description'        => __( 'Description.', 'bussness' ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'Services' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 7,
			'menu_icon'          => 'dashicons-align-right',
			'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
		];

		register_post_type( 'services', $args );
	}
endif;

/**
 * @see About
 */
add_action( 'init', 'bussness_register_post_about' );

if( ! function_exists( 'bussness_register_post_about' ) ) :

	// create post type about
	function bussness_register_post_about(){
		$labels = [
			'name'               => __( 'About Us', 'bussness'),
			'singular_name'      => __( 'About', 'bussness'),
			'menu_name'          => __( 'About Us', 'bussness'),
			'name_admin_bar'     => __( 'Add Member', 'bussness'),
			'add_new'            => __( 'Add New', 'bussness'),
			'add_new_item'       => __( 'Add New Member', 'bussness' ),
			'new_item'           => __( 'New Member', 'bussness' ),
			'edit_item'          => __( 'Edit Member', 'bussness' ),
			'view_item'          => __( 'View Member', 'bussness' ),
			'all_items'          => __( 'All Members', 'bussness' ),
			'search_items'       => __( 'Search Members', 'bussness' ),
			'parent_item_colon'  => __( 'Parent Members:', 'bussness' ),
			'not_found'          => __( 'No Member found.', 'bussness' ),
			'not_found_in_trash' => __( 'No Member found in Trash.', 'bussness' )
		];

		$args = [
			'labels'             => $labels,
	    'description'        => __( 'Description.', 'bussness' ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'about' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 7,
			'menu_icon'          => 'dashicons-admin-users',
			'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments','slug' )
		];

		register_post_type( 'about', $args );
	}
endif;

/**
 * @see Contact
 */
add_action( 'init', 'bussness_register_post_contact_form' );

if( ! function_exists( 'bussness_register_post_contact_form' ) ) :

	// create post type about
	function bussness_register_post_contact_form(){
		$labels = [
			'name'               => __( 'Contact Footer', 'bussness'),
			'singular_name'      => __( 'Contact', 'bussness'),
			'menu_name'          => __( 'Contact Footer', 'bussness'),
			'name_admin_bar'     => __( 'Add Form', 'bussness'),
			'add_new'            => __( 'Add New', 'bussness'),
			'add_new_item'       => __( 'Add New Form', 'bussness' ),
			'new_item'           => __( 'New Form', 'bussness' ),
			'edit_item'          => __( 'Edit Form', 'bussness' ),
			'view_item'          => __( 'View Form', 'bussness' ),
			'all_items'          => __( 'All Forms', 'bussness' ),
			'search_items'       => __( 'Search Members', 'bussness' ),
			'parent_item_colon'  => __( 'Parent Members:', 'bussness' ),
			'not_found'          => __( 'No Form found.', 'bussness' ),
			'not_found_in_trash' => __( 'No Form found in Trash.', 'bussness' )
		];

		$args = [
			'labels'             => $labels,
	    'description'        => __( 'Description.', 'bussness' ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'contact' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 8,
			'menu_icon'          => 'dashicons-format-chat',
			'supports'           => array( 'editor' )
		];

		register_post_type( 'custom_contact', $args );
	}
endif;


/**
 * @see Portfolios
 */
add_action( 'init', 'bussness_register_portfolios' );

if( ! function_exists( 'bussness_register_portfolios' ) ) :

	// create post type about
	function bussness_register_portfolios(){
		$labels = [
			'name'               => __( 'Portfolios', 'bussness'),
			'singular_name'      => __( 'Portfolio', 'bussness'),
			'menu_name'          => __( 'Portfolios', 'bussness'),
			'name_admin_bar'     => __( 'Add Portfolio', 'bussness'),
			'add_new'            => __( 'Add New', 'bussness'),
			'add_new_item'       => __( 'Add New Portfolio', 'bussness' ),
			'new_item'           => __( 'New Portfolio', 'bussness' ),
			'edit_item'          => __( 'Edit Portfolio', 'bussness' ),
			'view_item'          => __( 'View Portfolio', 'bussness' ),
			'all_items'          => __( 'All Portfolios', 'bussness' ),
			'search_items'       => __( 'Search Portfolios', 'bussness' ),
			'parent_item_colon'  => __( 'Parent Portfolios:', 'bussness' ),
			'not_found'          => __( 'No Portfolio found.', 'bussness' ),
			'not_found_in_trash' => __( 'No Portfolio found in Trash.', 'bussness' )
		];

		$args = [
			'labels'             => $labels,
	    'description'        => __( 'Description.', 'bussness' ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'contact' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 9,
			'menu_icon'          => 'dashicons-format-chat',
			'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments','slug' )
		];

		register_post_type( 'portfolios', $args );
	}
endif;