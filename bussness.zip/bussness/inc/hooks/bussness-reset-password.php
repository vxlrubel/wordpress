<?php 
add_action( 'bussness_reset_password', 'bussness_reset_passwords' );

function bussness_reset_passwords(){ ?>
	<div class="modal fade" id="resetPassword" tabindex="-1" role="dialog" aria-hidden="true">
	  <form action="<?php echo esc_url(wp_lostpassword_url()); ?>" class="modal-dialog modal-dialog-scrollable" role="document" method="post" name="lostpasswordform" novalidate="novalidate">
	    <div class="modal-content bg-light">
	      <div class="modal-header">
	        <h5 class="modal-title">Generate New Password</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	      	<p class="message small">Please enter your username or email address. You will receive a link to create a new password via email.</p>
					<p>
	      	<p class="error small"><strong>ERROR:</strong> Enter a username or email address.</p>

					<p>
						<label for="user_login">Username or Email Address</label>
						<input type="text" name="user_login" id="user_login" class="form-control" required="">
					</p>
	      </div>
	      <div class="modal-footer">
	      	<button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
	        <input type="hidden" name="redirect_to" value="">
	        <input type="submit" name="wp-submit" class="btn btn-sm btn-primary" value="Get New Password">
	      </div>
	    </div>
	  </form>
	</div>

<?php 
}