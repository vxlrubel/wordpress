<?php 
add_action( 'bussness_login_form', 'bussness_login_details' );
function bussness_login_details(){ ?>

	<div class="modal fade" id="userLoginForm" tabindex="-1" role="dialog" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <form class="modal-content" name="loginform" action="<?php echo esc_url( wp_login_url() ); ?>" method="post">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Login Form</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	      	<p>
		      	<label for="name">Username or Email</label>
		        <input type="text" name="log" class="form-control" required="" id="name" placeholder="Username">
	      	</p>
	      	<p>
	      	<label for="pwd">Password</label>
	        <input type="password" name="pwd" class="form-control" id="pwd" required="" placeholder="Password">
	      	</p>
    			<p>
  					<input name="rememberme" type="checkbox" id="rememberme" value="forever">
  					<label for="rememberme"> Remember Me</label>
  					<a href="" class="float-right" data-toggle="modal" data-target="#resetPassword">Forget Password</a>
    			</p>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
	        <button type="submit" name="wp-submit" class="btn btn-sm btn-primary">Log In</button>
	        <input type="hidden" name="redirect_to" value="<?php echo esc_url( home_url('/') ); ?>">
	      </div>
	    </form>

	  </div>
	</div>

<?php
}