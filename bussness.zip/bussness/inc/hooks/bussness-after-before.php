<?php 
/**
 * @see Main section before
 */

add_action( 'section_before', 'bussness_before_section' );

if( ! function_exists( 'bussness_before_section' ) ) :
	function bussness_before_section(){
		$before_section = '<section class="clearfix mb-3">';
		$before_section .= '<div class="container-fluid">';
		$before_section .= '<div class="row">';
		echo $before_section;
	}
endif;

/**
 * @see Main section after
 */

add_action( 'section_after', 'bussness_after_section' );

if( ! function_exists( 'bussness_after_section' ) ) :
	function bussness_after_section(){
		$before_section = "</div> \n";
		$before_section .= "</div> \n";
		$before_section .= "</section> \n";
		echo $before_section;
	}
endif;