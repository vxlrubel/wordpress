<?php 
add_action( 'bussness_user_logout', 'bussness_user_logout_details' );

function bussness_user_logout_details(){
	printf('<li><a href="login-url.php" data-toggle="modal" data-target="#userLoginForm">'.esc_html('Login').'</a>	</li>');
	printf('<li><a href="create-new-user.php" data-toggle="modal" data-target="#createNewUser">'.esc_html('Register').'</a>	</li>');
	printf('<li><a href="create-new-user.php" data-toggle="modal" data-target="#resetPassword">'.esc_html('Reset').'</a>	</li>');
}