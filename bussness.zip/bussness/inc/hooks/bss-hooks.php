<?php 
/**
 * @author Mrm Sujan
 * @copyright © Copyriht by Mrm Sujan.
 * @package Bussness
 * @subpackage Include All hooks.
 * @since 1.1.0
 * @see ALL HOOKS FILES
 */

/**
 * @see section after and before
 */
require_once dirname(__FILE__) . './bussness-after-before.php';

/**
 * @see New user form
 */
require_once dirname(__FILE__) . './bussness-create-new-user.php';

/**
 * @see User login form
 */
require_once dirname(__FILE__) . './bussness-login-form.php';

/**
 * @see User reset password form
 */
require_once dirname(__FILE__) . './bussness-reset-password.php';

/**
 * @see Search query
 */
require_once dirname(__FILE__) . './bussness-search-query.php';

/**
 * @see User logout form
 */
require_once dirname(__FILE__) . './bussness-user-logout.php';

/**
 * @see User login form
 */
require_once dirname(__FILE__) . './bussness-user-lonin.php';