<?php 
add_action( 'bussness_create_new_user', 'bussness_create_new_user_details' );

function bussness_create_new_user_details(){ ?>
	<div class="modal fade" id="createNewUser" tabindex="-1" role="dialog" aria-hidden="true">
	  <form action="<?php echo esc_url(home_url('/wp-admin/user-new.php')); ?>" class="modal-dialog modal-dialog-scrollable modal-lg" role="document" method="post" name="createuser" novalidate="novalidate">
	  	<input name="action" type="hidden" value="createuser">
	  	<input type="hidden" id="_wpnonce_create-user" name="_wpnonce_create-user" value="fc1fc72fc7">
	  	<input type="hidden" name="_wp_http_referer" value="/wp/wp-admin/user-new.php">

	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title">
	        	<?php esc_html_e( 'Create New User', 'bussness' ); ?>
	        </h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body create-new-user">
	      	<p>
		        <?php
		         $content = 'Username (required)';
		         bss_label( 'user_login', $content );
		         bss_input_r( 'text', 'user_login', 'float-right', 'user_login');
		         ?>
	      	</p>
	      	<p>
	      		<?php 
	      		 $content = 'Email (required)';
	      		 bss_label( 'email_address', $content );
	      		 bss_input_r( 'email', 'email', '', 'email_address' );
	      		 ?>
	      	</p>
	      	<p>
	      		<?php 
	      		 $content = 'First Name';
	      		 bss_label( 'first_name', $content );
	      		 bss_input( 'text', 'first_name', '', 'first_name' );
	      		 ?>
	      	</p>
	      	<p>
	      		<?php 
	      		 $content = 'Last Name';
	      		 bss_label( 'last_name', $content );
	      		 bss_input( 'text', 'last_name', '', 'last_name' );
	      		 ?>
	      	</p>
	      	<p>
	      		<?php 
	      		 $content = 'Website';
	      		 bss_label( 'url', $content );
	      		 bss_input( 'url', 'url', '', 'url' );
	      		 ?>
	      	</p>
	      	<p>
	      		<?php 
	      		 $content = 'Password (required)';
	      		 bss_label( 'pass1', $content );
	      		 bss_input_r( 'password', 'pass1', '', 'pass1' );
	      		 ?>
	      	</p>
	      	<p>
	      		<?php 
	      		 $content = 'Repeat Password (required)';
	      		 bss_label( 'pass2', $content );
	      		 bss_input_r( 'password', 'pass2', '', 'pass2' );
	      		 ?>
	      	</p>
	      	<p style="display: none;">
	      		<?php 
	      		 bss_input( 'checkbox', 'pw_weak', '', 'wp_check_con' );
	      		 bss_label( 'wp_check_con' );
	      		 ?>
	      	</p>
	      	<p>
	      		<?php bss_label( 'role', 'Role'); ?>
	      		<select name="role" id="role">
	      			<?php 
	      			 bss_option( 'subscriber', 'Subscriber', 'selected' );
	      			 bss_option( 'contributor', 'Contributor' );
	      			 bss_option( 'author', 'Author' );
	      			 bss_option( 'editor', 'Editor' );
	      			 bss_option( 'administrator', 'Administrator' );
	      			 ?>	
	      		</select>
	      	</p>
					<p>
						<input type="checkbox" name="send_user_notification" id="send_user_notification" value="1" checked="checked">
						<label for="send_user_notification">
							<?php esc_html_e( 'Send the new user an email about their account.', 'bussness' ); ?>
						</label>
					</p>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">
	        	<?php esc_html_e( 'Close', 'bussness' ); ?>
	        </button>
	        <input type="submit" name="createuser" id="createusersub" class="btn btn-sm btn-primary" value="Add New User">
	      </div>
	    </div>
	  </form>
	</div>

<?php 
}