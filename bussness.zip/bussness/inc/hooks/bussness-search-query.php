
<?php 
function bussness_search_query(){
 ?>
	<div class="row">
		<div class="col-12 pt-3">
			<div class="row">
				<?php if (have_posts()): ?>
				<div class="col-12">
					<h4 class="mb-3 font-weight-lighter">
					<?php 
						printf('Search Result : '. esc_html( get_search_query()));
					 ?>
					</h4>
				</div>
				<?php while(have_posts()) : the_post(); ?>
				<div class="col-12 my-2">
					<div class="row">
						<div class="col-3 col-lg-2">
							<?php the_post_thumbnail('search-thumb'); ?>

						</div>
						<div class="col-9 col-lg-10">
							<a href="<?php the_permalink(); ?>" class="text-decoration-none font-weight-bold">
								<?php the_title(); ?>
							</a>
							<p class="text-justify">
								<?php wp_trim(10); ?>
							</p>
						</div>
					</div>
				</div>
				<?php endwhile; ?>
				<?php else: ?>
				<div class="col-12">
					<h4 class="mb-3 font-weight-lighter">
						<?php 
						printf(__('Search Result : "', 'bussness'). esc_html( get_search_query()).'" not found <span class="search-not-found-icon far fa-sad-tear text-warning"></span>')
						 ?>
					
					</h4>
					<div class="search-not-found">
						<?php get_search_form(); ?>
					</div>
					<p class="mt-3">
						<?php 
						printf(__('May be you\'re looking for something else! please try again or you may visit the <a href="'.esc_url(home_url('/')).'" title="Welcome to Home">homepage.</a>', 'bussness'));
						 ?>
					</p>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
<?php 
}

add_action( 'bussness_search_query_result', 'bussness_search_query' );