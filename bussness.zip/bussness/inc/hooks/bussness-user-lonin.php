<?php 
add_action( 'bussness_user_login', 'bussness_user_login_details' );

function bussness_user_login_details(){ ?>
	<li class="profile-list">
		<span class="set_author far fa-user-circle"></span>
		<div class="profile-thumb">
		</div>
		<div class="user-dropdown">
			<?php bss_link( admin_url(), 'Dashboard' ); ?>
			<?php bss_link( get_edit_profile_url( $post->ID ), 'Edit Profile' ); ?>
			<?php bss_link( 'author-post.php', 'Author Posts', 'set_author_link' ); ?>
			<?php bss_link( wp_logout_url(), 'Log Out' ); ?>
		</div>
	</li>
<?php
}