<?php get_header(); ?>
<?php	do_action( 'section_before' ); ?>
<?php if ( have_posts() ): ?>
<?php while ( have_posts() ) : the_post(); ?>

<div class="col-12">
	<div class="row">
		<!-- single post -->
		<div class="col-12 mb-2">
			<div class="row">
				<div class="col-12 text-center">
					<h2 class="text-uppercase bg-info mb-0 pt-3 text-white"><?php the_title(); ?></h2>
					<p class="small bg-info pb-2 pt-1 text-light">
						<span><?php the_category(', '); ?> ||</span>
						<span><?php the_time('_F d, Y__g:iA'); ?> ||</span>
						<span>Posted by <?php the_author(); ?></span>
					</p>
				</div>
				<div class="col-12">
					<?php the_post_thumbnail(); ?>
					<p class="small mt-1">
						<span class="fab fa-facebook-messenger"></span>
						<span><?php comments_number(); ?></span>
						<span><?php the_time('_F d, Y'); ?></span>
					</p>
				</div>
				<div class="col-12">
					<div class="tags small mb-3">
						<?php $tags = __('This Post Tags: ', 'bussness'); ?>
						<?php the_tags( $tags, '', '' ); ?>

						<?php 
							$keyword = get_the_terms( get_the_ID(), 'keyword' );
							if( $keyword ) :
								foreach ($keyword as $keywords) {
									$name = esc_html( $keywords->name );
									$count = esc_html( $keywords->count );
									$link = esc_url( get_term_link( $keywords, 'keyword' ) );
									$return = '<a href="'.$link.'">'.$name.'('.$count.')</a>';
									printf( $return );
								}
							endif;
							
						 ?>
					</div>
				</div>
				<div class="col-12 text-justify mb-1">
					<?php the_title('<h4 class="text-uppercase">', '</h4>'); ?>
					<?php the_content(); ?>
				</div>
				<div class="col-sm-7 mb-3">
					<h5>
						<span class="fas fa-share-alt-square mr-1"></span>
						<span>Share this article on your social sites.</span>
					</h5>
				</div>
				<div class="col-sm-5 social-share mb-3">
					<?php BSS()->post->share_btn(); ?>
				</div>
				<div class="col-12">
					<div class="row">
						<?php BSS()->post->related_post(); ?>
					</div>
				</div>

			</div>
		</div>
		
		<?php get_template_part( 'template-part/navigation' ); ?>

		<!-- comment area -->
		<div class="col-12 my-3">
			<div class="row">
				<?php 
				if( ( is_single() || is_page() ) && ( comments_open() || get_comments_number() ) && ! post_password_required() ) :
					comments_template();
				endif;
				 ?>
				
			</div>
		</div>
	</div>
</div>
<?php endwhile; ?>
<?php endif; ?>
<?php	do_action( 'section_after' ); ?>
<?php get_footer(); ?>