<?php 
get_header();
	do_action( 'section_before' );
	$theme_inside_layout = $bussness['tl_layout_inside'];

	if ( $theme_inside_layout == 0 ):
		get_template_part( 'template-part/content', 'full-layout' );

	elseif ( $theme_inside_layout == 1 ):
		get_template_part( 'template-part/layout/content', 'default' );

	elseif ( $theme_inside_layout == 2 ):
		get_template_part( 'template-part/layout/content','2cl' );

	elseif ( $theme_inside_layout == 3 ):
		get_template_part( 'template-part/layout/content','2cr' );


	elseif ( $theme_inside_layout == 4 ) :
		get_template_part( 'template-part/layout/content','3cl' );

	elseif ( $theme_inside_layout == 5 ) :
		get_template_part( 'template-part/layout/content','3cr' );
	endif;

	wp_reset_postdata();
	
	do_action( 'section_after' );

get_footer(); 


