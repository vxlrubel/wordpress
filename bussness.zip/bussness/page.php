
<?php 

get_header();
	do_action( 'section_before' );
		echo '<div class="col-12 mb-2">';
			if( have_posts() ) :
				while( have_posts() ) : the_post();
					get_template_part( 'template-part/page/content', 'page' );
					
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
				endwhile;
			endif;
		echo "</div> \n";
	do_action( 'section_after' );
get_footer();